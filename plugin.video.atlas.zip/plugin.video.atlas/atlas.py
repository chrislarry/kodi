# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,webbrowser,json,random,time
import base64
import resolveurl
import pyxbmct

from resources.lib.modules import plugintools
from resources.lib.get import youtube
from resources.lib.get import ell
from resources.lib.get import series
from resources.lib.get import movies
from resources.lib.get import kids
from resources.lib.get import old
from resources.lib.get import doc
from resources.lib.get import hermes
from resources.lib.get import fishing
from resources.lib.get import webcam
from resources.lib.get import cypros
from resources.lib.get import spor
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import addon
from resources.lib.clean import tool
from resources.lib.clean import pair
from t0mm0.common.net import Net as net

def Main_menu():
    openn.addDir('[B][COLOR yellow]' +addon.Lang(33000).encode('utf-8')+ '[/COLOR][/B]','',500,addon.icon,addon.art,'')
    openn.addDir('[B][COLOR white]Hermes Addon[/COLOR][/B]','',420,'https://i.imgur.com/hlZ8sAZ.png',addon.art,'Hermes addon.') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32000).encode('utf-8')+ '[/COLOR][/B]','',75,'http://i.imgur.com/cTv0fXe.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32001).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/tvshows/',800,'http://i.imgur.com/ypLPk5x.png',addon.art,'Ξένες σείρες με υπότιτλους.\nSeries with greek subtitles.') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32002).encode('utf-8')+ '[/COLOR][/B]','',74,'http://i.imgur.com/QGC87GD.png',addon.art,'Ελληνικές ταινίες & σειρές.\nGreek movies & series.')       
    openn.addDir('[B][COLOR white]' +addon.Lang(32003).encode('utf-8')+ '[/COLOR][/B]','',76,'http://i.imgur.com/jTaJF0B.png',addon.art,'Ντοκιμντέρ μεταγλωτισμένα & με υπότιτλους.\nDocumenter dubbed & subtitled.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32004).encode('utf-8')+ '[/COLOR][/B]','',72,'http://i.imgur.com/Jhjod4P.png',addon.art,'Παλιές σειρές & Παιδικά.\nOld series & kids.')        
    openn.addDir('[B][COLOR white]' +addon.Lang(32005).encode('utf-8')+ '[/COLOR][/B]','',77,'http://i.imgur.com/T8NlaOf.png',addon.art,'Παιδικές ταινίες μεταγλωτισμνένες & με υπότιτλους & άλλα διάφορα.\nChildren movies dubbed & subtitled & more.')        
    openn.addDir('[B][COLOR white]' +addon.Lang(32098).encode('utf-8')+ '[/COLOR][/B]','http://la8osapofash.com',806,'https://i.imgur.com/0Exal6r.png',addon.art,'Αγώνες σε επανάληψη.\nReplays full match.') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32006).encode('utf-8')+ '[/COLOR][/B]','',601,'http://i.imgur.com/edOpGQt.png',addon.art,'Νέα από τις ομάδες από youtube.\nNews from the greek teams from youtube.')       
    openn.addDir('[B][COLOR white]' +addon.Lang(32007).encode('utf-8')+ '[/COLOR][/B]','',79,'http://i.imgur.com/vFEDZB2.png',addon.art,'Διάφορα βίντεο από youtube.\nVarious videos from YouTube')
    openn.addDir('[B][COLOR white]' +addon.Lang(32093).encode('utf-8')+ '[/COLOR][/B]','',801,'https://i.imgur.com/CIx5iC8.png',addon.art,'Τρέιλερ με υπότιτλους.\nTrailers with greek soubs.')            
    openn.addDir('[B][COLOR white]' +addon.Lang(32094).encode('utf-8')+ '[/COLOR][/B]','',456,'https://i.imgur.com/9SvI277.png',addon.art,'Κανάλι ψαρέματος.\nFishing.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32095).encode('utf-8')+ '[/COLOR][/B]','',610,'https://i.imgur.com/9wH7kFE.png',addon.art,'Ελληνικές κάμερες.\nGreek Webcam.') 
    #openn.addLink('[B][COLOR blue]GreekTV[/COLOR][/B]','special://home/addons/plugin.video.atlas/resources/gr.m3u',805,'https://i.imgur.com/ntL0ThK.png',addon.art,'Ελληνική τηλεόραση.\nGreek TV.')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32097).encode('utf-8')+ '[/COLOR][/B]','',461,'https://i.imgur.com/0DP0AWK.png',addon.art,'Κυπριακή τηλεόραση.\nCyprus TV.')
    openn.addLink('[B][COLOR white]' +addon.Lang(32096).encode('utf-8')+ '[/COLOR][/B]','special://home/addons/plugin.video.atlas/resources/radio.m3u','','https://i.imgur.com/qNaz8Ig.png',addon.art,'Ελληνικό ράδιο.\nGreek radio.')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32008).encode('utf-8')+ '[/COLOR][/B]','',73,'http://i.imgur.com/PYWFxS3.png',addon.art,'Μουσική από youtube.\nMusic from youtube.')        
    openn.addDir('[B][COLOR white]Pairing [/COLOR][/B]','',808,'https://i.imgur.com/EFOFsna.png',addon.art,'pair')     
    openn.addDir('[B][COLOR white]Maintanance[/COLOR][/B]','',557,'https://i.imgur.com/2cPUPkf.png',addon.art,'clean')
    icon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.atlas','icon.png'))
    xbmcgui.Dialog().notification('Ευχαριστούμε που επιλέξατε','Το Ελληνικό Ατλας!!!',icon,5000,False)

def MOVIES():
    openn.addDir('[B][COLOR white]' +addon.Lang(32012).encode('utf-8')+ ' [/COLOR][COLOR green]Tainies4k[/COLOR][/B]','http://tainies4k.online/movies/',70,'http://tainies4k.online/wp-content/uploads/2017/01/logo1.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32013).encode('utf-8')+ ' [/COLOR][COLOR green]Tainies4k[/COLOR][/B]','http://tainies4k.online/movies/',78,'http://tainies4k.online/wp-content/uploads/2017/01/logo1.png',addon.art,'Ξένες ταινίες ανα έτος με υπότιτλους.\nMovies per year with subtitles.')       
    openn.addDir('[B][COLOR white]' +addon.Lang(32038).encode('utf-8')+ ' [/COLOR][COLOR green]Tainies4k[/COLOR][/B]','http://tainies4k.online/movies/',13,'http://tainies4k.online/wp-content/uploads/2017/01/logo1.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Tainies4k[/COLOR][/B]','http://tainies4k.online/',96,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'[B][COLOR green]Αναζήτηση[/COLOR][/B]')
    openn.addDir('[B][COLOR white]' +addon.Lang(32012).encode('utf-8')+ ' [/COLOR][COLOR green]Gamato.tv[/COLOR][/B]','',25,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')      
    openn.addDir('[B][COLOR white]' +addon.Lang(32038).encode('utf-8')+ ' [/COLOR][COLOR green]Gamato.tv[/COLOR][/B]','http://gamatotv.me/groups?sort=mostRecent',26,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'Ξενες ταινιες με υποτιτλους.')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Gamato.Tv[/COLOR][/B]','http://gamatotv.me/',97,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32012).encode('utf-8')+ ' [/COLOR][COLOR green]Peirates[/COLOR][/B]','https://oipeirates.online/',103,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32038).encode('utf-8')+ ' [/COLOR][COLOR green]Peirates[/COLOR][/B]','https://oipeirates.online/tenies-online/2017/',9,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Peirates[/COLOR][/B]','https://oipeirates.online/',99,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'')  
    openn.addDir('[B][COLOR white]' +addon.Lang(32012).encode('utf-8')+ ' [/COLOR][COLOR green]Xrusoi[/COLOR][/B]','https://xrysoi.online/',164,'https://xrysoi.online/wp-content/uploads/2015/03/logo-GM.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32092).encode('utf-8')+ ' [/COLOR][COLOR green]Xrusoi[/COLOR][/B]','https://xrysoi.online/category/tainiesonline/2017/',313,'https://images.vexels.com/media/users/3/128466/isolated/preview/f73073b2833de121056fabab1003913f-promotional-flipped-sale-sticker-by-vexels.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')   
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Xrysoi[/COLOR][/B]','https://xrysoi.online/',165,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'')
    openn.addDir('[B][COLOR white]hd quality[/COLOR][/B]','http://tainies4k.online/quality/high/',13,'http://www.videoconverterfactory.com/glossary/imgs/h263.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR white]720p quality[/COLOR][/B]','http://tainies4k.online/quality/medium/',13,'http://www.webcam-for-mac.com/hi-def-web-cams.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.')
    openn.addDir('[B][COLOR white]sd quality[/COLOR][/B]','http://tainies4k.online/quality/low/',13,'https://cdn2.iconfinder.com/data/icons/video-quality-2/64/Video_Quality_Cinema_LQ-512.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.') 
    #openn.addDir('[B][COLOR white]test[/COLOR][/B]','',803,'https://cdn2.iconfinder.com/data/icons/video-quality-2/64/Video_Quality_Cinema_LQ-512.png',addon.art,'Ξένες ταινίες με υπότιτλους.\nMovies with greek subtitles.') 

def SERIES():
    openn.addDir('[B][COLOR white]' +addon.Lang(32013).encode('utf-8')+ ' [/COLOR][COLOR green]Tainies4k[/COLOR][/B]','http://tainies4k.online/tvshows/',501,'http://tainies4k.online/wp-content/uploads/2017/01/logo1.png',addon.art,'Ξένες σείρες με υπότιτλους.\nSeries with greek subtitles.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32001).encode('utf-8')+ ' [/COLOR][COLOR green]Tainies4k[/COLOR][/B]','http://tainies4k.online/tvshows/',24,'http://tainies4k.online/wp-content/uploads/2017/01/logo1.png',addon.art,'Ξένες σείρες με υπότιτλους.\nSeries with greek subtitles.')    
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Tainies4k[/COLOR][/B]','',92,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'[B][COLOR green]Αναζήτηση[/COLOR][/B]')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32001).encode('utf-8')+ '[/COLOR][COLOR green] Xrysoi[/COLOR][/B]','https://xrysoi.online/category/%CE%BE%CE%AD%CE%BD%CE%B5%CF%82-%CF%83%CE%B5%CE%B9%CF%81%CE%AD%CF%82/',416,'https://xrysoi.online/wp-content/uploads/2015/03/logo-GM.png',addon.art,'Ξένες σείρες με υπότιτλους.\nSeries with greek subtitles.')              
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Xrysoi[/COLOR][/B]','https://oipeirates.online/',319,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'[B][COLOR green]Αναζήτηση[/COLOR][/B]')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32001).encode('utf-8')+ '[/COLOR][COLOR green] Peirates[/COLOR][/B]','https://oipeirates.online/tenies-online/seires',55,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'Ξένες σείρες με υπότιτλους.\nSeries with greek subtitles.')               
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Peirates[/COLOR][/B]','https://oipeirates.online/',93,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'[B][COLOR green]Αναζήτηση[/COLOR][/B]')   

def GREEK():
    openn.addDir('[B][COLOR white]' +addon.Lang(32014).encode('utf-8')+ '[/COLOR][/B]','',34,'http://i.imgur.com/QGC87GD.png',addon.art,'Ελληνικές ταινίες & σειρές.\nGreek movies & series.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32002).encode('utf-8')+ '[/COLOR][COLOR green] Tainies4k[/COLOR][/B]','http://tainies4k.online/category/ellinikes/',13,'http://tainies4k.online/wp-content/uploads/2017/01/logo1.png',addon.art,'Ελληνικές ταινίες.\nGreek movies.')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Tainies4k[/COLOR][/B]','http://tainies4k.online/',96,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'[B][COLOR green]Αναζήτηση[/COLOR][/B]') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32002).encode('utf-8')+ '[/COLOR][COLOR green] Xrusoi[/COLOR][/B]','https://xrysoi.online/category/ελλ-ταινίες/',313,'https://xrysoi.online/wp-content/uploads/2015/03/logo-GM.png',addon.art,'Ελληνικές ταινίες.\nGreek movies.')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ ' Xrysoi[/COLOR][/B]','https://oipeirates.online/',319,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'[B][COLOR green]Αναζήτηση[/COLOR][/B]')

def DOCU():
    openn.addDir('[B][COLOR white]' +addon.Lang(32015).encode('utf-8')+ '[/COLOR][/B]','',61,'http://ntokimanter.gr/wp-content/uploads/2016/04/ntokimanter_logo.png',addon.art,'Ντοκιμντέρ μεταγλωτισμένα & με υπότιτλους.\nDocumenter dubbed & subtitled.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32003).encode('utf-8')+ '[/COLOR][/B]','',600,'http://i.imgur.com/jTaJF0B.png',addon.art,'Ντοκιμντέρ μεταγλωτισμένα & με υπότιτλους.\nDocumenter dubbed & subtitled.')

def KIDS():
    openn.addDir('[B][COLOR white]Yousmile.gr[/COLOR][/B]','',1000,'http://www.yousmile.gr/sites/default/files/logo_0.png',addon.art,'')
    class MyWindow(pyxbmct.AddonDialogWindow):

        def __init__(self, title=''):
            super(MyWindow, self).__init__(title)
            self.setGeometry(700, 500, 5, 2)
            self.set_controls()
            self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

        def set_controls(self):
            image = pyxbmct.Image('http://www.yousmile.gr/sites/all/themes/yousmile/images/contact_block.png')
            self.placeControl(image, 0, 0, 4, 1)
            self.textbox = pyxbmct.TextBox()
            self.placeControl(self.textbox, 0, 1, 4, 1)
            self.textbox.setText('[B][COLOR yellow]«ΤΙ ΚΑΝΩ ΤΩΡΑ;;;»«ΣΕ ΠΟΙΟΝ ΜΠΟΡΩ ΝΑ ΜΙΛΗΣΩ;;;»«ΠΟΙΟΣ ΘΕΛΕΙ ΝΑ ΜΕ ΑΚΟΥΣΕΙ;;;»[/COLOR][/B],\n''Εθνική Τηλεφωνική Γραμμή για τα Παιδιά SOS 1056.'
                'Μια Γραμμή που γίνεται… σύνθημα βοήθειας. Μια Γραμμή που μπορείς…να καλέσεις όλο το 24ωρο, 365 ημέρες το χρόνο,'
                ' είναι δωρεάν και δε χρειάζεται να μας πεις το όνομα σου.Θα ακούσουμε τις ανησυχίες αλλά και τα προβλήματα σου,'
                ' μαζί θα βρούμε τις επιλογές και τις λύσεις που έχεις ενώ σε περίπτωση που κινδυνεύεις ή καταπατάται κάποιο από τα δικαιώματα σου,'
                ' θα σου δώσουμε την βοήθεια που πρέπει. Θα σε ακούσουμε επίσης και για το πρόβλημα του φίλου σου.'
                'Δεν θα πούμε σε κανένα ότι κάλεσες ούτε μπορούμε να εντοπίσουμε από πού μας κάλεσες ή μας έστειλες το e-mail.'
                'Μπορείς να επικοινωνήσεις μαζί μας για οτιδήποτε σε απασχολεί και με οποιονδήποτε τρόπο επιθυμείς.'
                'Είμαστε εδώ για σέναΠερισσότερα για την Εθνική Τηλεφωνική Γραμμή για τα Παιδιά SOS 1056')
            self.textbox.autoScroll(4000, 4000, 5000)
            self.fade_label = pyxbmct.FadeLabel()
            self.placeControl(self.fade_label, 4, 1)
            self.fade_label.addLabel('[B][COLOR yellow]https://www.hamogelo.gr''\n''e-mail:sos1056@hamogelo.gr''\n' 'Γραμμή για τα Παιδιά SOS 1056[/COLOR][/B]')
            self.close_button = pyxbmct.Button('[B][COLOR white]Κλείσε για Παιδικά[/COLOR][/B]''\n''(Return σε Android)')
            self.placeControl(self.close_button, 4, 0)
            self.connect(self.close_button, self.close)

        def setAnimation(self, control):
            control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])


    window = MyWindow('ΤΟ ΧΑΜΟΓΕΛΟ ΤΟΥ ΠΑΙΔΙΟΥ')
    window.doModal()
    del window      
    
    openn.addDir('[B][COLOR white]' +addon.Lang(32016).encode('utf-8')+ '[/COLOR][/B]','',28,'http://paidikestainies.online/wp-content/uploads/2017/01/paidikestainies.logo_.png',addon.art,'Παιδικές ταινίες μεταγλωτισμνένες & με υπότιτλους.\nChildren movies dubbed & subtitled.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32017).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/listByLocation?location=%CE%A0%CE%B1%CE%B9%CE%B4%CE%B9%CE%BA%CE%AC&sort=mostRecent',26,'https://brisfekusis.files.wordpress.com/2010/06/tracker-gamato-me.jpg',addon.art,'')        
    openn.addDir('[B][COLOR white]' +addon.Lang(32021).encode('utf-8')+ '[/COLOR][/B]','https://oipeirates.online/tenies-online/kin-sxedia-subs',9,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32017).encode('utf-8')+ '[/COLOR][/B]','https://oipeirates.online/tenies-online/kin-sxedia',9,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32019).encode('utf-8')+ '[/COLOR][/B]','',71,'http://i.imgur.com/6bEuWDo.png',addon.art,'Παιδικές ταινίες μεταγλωτισμνένες & με υπότιτλους & άλλα.\nChildren movies dubbed & subtitled & more.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32020).encode('utf-8')+ '[/COLOR][/B]','',603,'http://i.imgur.com/6bEuWDo.png',addon.art,'Παιδικά κανάλια youtube.\nChildren youtube channels.')
    openn.addDir('[B][COLOR white]' +addon.Lang(32017).encode('utf-8')+ ' [/COLOR][COLOR green]peirates[/COLOR][/B]','https://oipeirates.online/',104,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'Παιδικές ταινίες μεταγλωτισμνένες & με υπότιτλους.\nChildren movies dubbed & subtitled.')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32017).encode('utf-8')+ ' [/COLOR][COLOR green]gamatotv[/COLOR][/B]','http://gamatotv.me/groups/group/',105,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'Παιδικές ταινίες μεταγλωτισμνένες & με υπότιτλους.\nChildren movies dubbed & subtitled.')

def DIAFORA():
    openn.addDir('[B][COLOR white]' +addon.Lang(32007).encode('utf-8')+ '[/COLOR][/B]','',87,'http://i.imgur.com/vFEDZB2.png',addon.art,'Διάφορα βίντεο από youtube.\nVarious videos from YouTube')  
    openn.addDir('[B][COLOR white]' +addon.Lang(32007).encode('utf-8')+ ' Official[/COLOR][/B]','',602,'http://i.imgur.com/vFEDZB2.png',addon.art,'Διάφορα βίντεο από youtube.\nVarious videos from YouTube.')

def CYPROS():
    openn.addLink('[B][COLOR white]ALFASPORTSTV[/COLOR][/B]''[B][COLOR green] LIVE[/COLOR][/B]','http://l9.cloudskep.com/alsports/al24/playlist.m3u8','','http://alfasports.tv/wp-content/uploads/2017/07/19650478_10213391687526137_730682022_o.png','','LIVE SPORTS')
    openn.addDir('[B][COLOR white]SPORTS[/COLOR][/B]','',459,'http://www.sport24.gr/incoming/article3642556.ece/BINARY/original',addon.art,'Κανάλια από youtube.\nChannels from YouTube.')  
    openn.addDir('[B][COLOR white]NEWS[/COLOR][/B]','',460,'http://www.sport24.gr/incoming/article3642556.ece/BINARY/original',addon.art,'Κανάλια από youtube.\nChannels from YouTube.')
    openn.addDir('[B][COLOR white]RADIO[/COLOR][/B]','',462,'http://www.sport24.gr/incoming/article3642556.ece/BINARY/original',addon.art,'Ράδιο.\nRadios.')    
                                  
#############################################################################################################################################################################################################
pyxbmct.skin.estuary = False 
def confirm():
    class MyWindow(pyxbmct.AddonDialogWindow):

        def __init__(self, title=''):
            super(MyWindow, self).__init__(title)
            self.setGeometry(700, 500, 5, 2)
            self.set_controls()
            self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

        def set_controls(self):
            image = pyxbmct.Image('https://i.imgur.com/23IXvkd.png')
            self.placeControl(image, 0, 0, 3, 1)
            self.fade_label = pyxbmct.FadeLabel()
            self.placeControl(self.fade_label, 3, 0)
            self.fade_label.addLabel('[B][COLOR white]Ευχαριστούμε που επιλέξατε το Ελληνικό Ατλας!!![/COLOR][/B]')
            self.close_button = pyxbmct.Button('Close''\n''(Return σε Android)')
            self.placeControl(self.close_button, 4, 0)
            self.connect(self.close_button, self.close)
            self.textbox = pyxbmct.TextBox()
            self.placeControl(self.textbox, 0, 1, 4, 1)
            self.textbox.setText('Το πρόσθετο Atlas αποτελεί έναν κατάλογο αναζήτησης περιεχομένου από ελεύθερα διαθέσιμες ιστοσελίδες στο διαδίκτυο.\nΟι δημιουργοί του δεν φέρουν καμία ευθύνη για το περιεχόμενο και την αναπαραγωγή των ροών ως αποτέλεσμα της αναζήτησης.\nΟι δημιουργοί του πρόσθετου δεν φιλοξενούν, δεν αναπαράγουν ούτε έχουν καμία σχέση με τις ιστοσελίδες που παρέχουν το περιεχόμενο των ροών ως αποτελεσμα της αναζήτησης.')
            self.textbox.autoScroll(2000, 2000, 2000)

        def setAnimation(self, control):
            control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])

    window = MyWindow('[B][COLOR white]ATLAS VERSION 0.2.9[/COLOR][/B]')
    window.doModal()
    del window  
    return(Main_menu())

##########################################################################################################################################################
def notification(title, message, ms, nart):
    xbmc.executebuiltin("XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")") 

def doc_susres(name,url,description):
    try:    
        p = openn.Open_Url(url)
        url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(p)[0]
        stream_url = resolveurl.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description })
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(stream_url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        notification('ATLAS','Δεν Υπαρχει','5000', addon.icon)

def PLAY(name,url,description):
    try:
        name = name.split('[B][COLOR green]')[0]
        stream_url = resolveurl.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description })
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except: 
        notification('ATLAS','Δεν Υπαρχει','5000', addon.icon)



def yousmile(url):
    try:    
        r = requests.get(url)
        soup = BeautifulSoup(r.content, "html.parser")
        for a in soup.findAll(class_="media-youtube-preview-wrapper"):
             url = a.embed['src']
        stream_url = resolveurl.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description })
        liz.setProperty("IsPlayable","true")
        liz.setPath(str(stream_url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        notification('ATLAS','Δεν Υπαρχει','5000', addon.icon)


def PLAYM3U(url):
    xbmc.Player().play(url)

 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2: 
                params=sys.argv[2] 
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}    
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
params=get_params()
url=None
name=None
iconimage=None
mode=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanaddon.art=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass

print str(addon.PATH)+': '+str(addon.VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)

if mode == None: Main_menu()
elif mode==1:youtube.get_content1(url)
elif mode==7:kids.KIDS8(url)
elif mode==8:kids.get_peirates(url)
elif mode==9:kids.peirates(url)
elif mode==10:old.get_old23(url)
elif mode==11:old.get_old11(url)
elif mode==13:movies.get_content(url)
elif mode==14:movies.GETSOURCES4k(url)
elif mode==16:youtube.GETSOURCES3(url)
elif mode==17:old.get_old17(url)
elif mode==18:old.get_old18(url)
elif mode==19:old.get_old19(url)
elif mode==20:old.get_old20(url)
elif mode==21:old.get_oldvidzi(url)
elif mode==22:old.get_old22(url)
elif mode==24:series.get_contS(url)
elif mode==25:movies.new()
elif mode==26:movies.katigoria(url)
elif mode==27:movies.susres(url)
elif mode==28:kids.newK()
elif mode==29:kids.katigoriaK(url)
elif mode==30:kids.susresK(url)
elif mode==31:kids.katigoriaK2(url)
elif mode==32:kids.susresK2(url)
elif mode==33:kids.katigoriaX(url)
elif mode==34:ell.ell()
elif mode==35:ell.katigoriaell(url)
elif mode==36:ell.getell(url)
elif mode==37:ell.getell2(url)
elif mode==38:ell.katigoriaell2(url)
elif mode==39:ell.katigoriaell3(url)
elif mode==40:ell.getell3(url)
elif mode==41:ell.getell4(url)
elif mode==42:ell.getellnew(url)
elif mode==60:doc.doc_content(url)
elif mode==61:doc.doc_menou()
elif mode==70:movies.Movie_menu()
elif mode==71:youtube.Kid_menu()
elif mode==72:old.Old_series()
elif mode==73:youtube.Moysik_menou()
elif mode==74:GREEK()
elif mode==75:MOVIES()
elif mode==76:DOCU()
elif mode==77:KIDS()
elif mode==79:DIAFORA()
elif mode==78:movies.get_xronia()
elif mode==83:series.SHOWS(url)
elif mode==84:kids.collection(url)
elif mode==87:youtube.diafora()
elif mode==88:ell.katigoriaell4(url)
elif mode==89:ell.katigoriaell5(url)
elif mode==96:movies.Search1()
elif mode==97:movies.Search2()
elif mode==98:kids.Search3()
elif mode==95:ell.Search4()
elif mode==94:ell.Search5()
elif mode==92:series.Search6()
elif mode==93:series.Search11()
elif mode==99:movies.Search7()
elif mode==165:movies.Search8()
elif mode==319:series.Search9()
elif mode==200:PLAY(name,url,description)
elif mode==300:doc_susres(name,url,description)
elif mode==250:PLAYM3U(url)
elif mode==350:radio.radio(name,url,mode,iconimage,fanart,description)
elif mode==600:youtube.youtube(params)
elif mode==601:youtube.komades(params)
elif mode==602:youtube.kdiafora(params)
elif mode==603:youtube.kids1(params)
elif mode==456:fishing.fishing(url)
elif mode==457:youtube.vh1(url)
elif mode==458:youtube.vevo(url)
elif mode==459:cypros.spor1(url)
elif mode==460:cypros.news1(url)
elif mode==461:CYPROS()
elif mode==462:cypros.radiocy()
elif mode==156:get_old11(url)
elif mode==312:movies.get_hdvid(url)
elif mode==313:movies.xrysoimovies(url)
elif mode==314:movies.get_xrysoimovies(url)
elif mode==419:hermes.hermes(url)
elif mode==420:hermes.hermesM(url)
elif mode==555:tool.katell()
elif mode==556:tool.auto_clean(url)
elif mode==557:tool.clean_menu()
elif mode==560:tool.vodil(url)
elif mode==808:pair.pair()
elif mode==809:pair.openload()
elif mode==810:pair.alluc()
elif mode==811:pair.videome()
elif mode==812:pair.vidupme()
elif mode==102:movies.Movie_menu2()
elif mode==103:movies.Movie_menu3()
elif mode==164:movies.Movie_menu4()
elif mode==107:Series_menu3()
elif mode==108:MySeries_menu3()
elif mode==104:kids.KIDSANIME_menu()
elif mode==105:kids.KIDSANIME_gamato()
elif mode==202:kids.KIDSANIME()
elif mode==561:tool.Installxe()
elif mode==416:series.xrysoiseries(url)
elif mode==55:series.peiratesseries(url)
elif mode==56:series.get_peiratesseries(url)
elif mode==312:series.get_hdvid(url)
elif mode==165:series.Search8()
elif mode==319:series.Search9()
elif mode==610:webcam.cam()
elif mode==801:youtube.GRtrailers(params)
elif mode==800:SERIES()
elif mode==802:movies.teniesonline(url)
elif mode==803:movies.Movie_menu6()
elif mode==804:movies.get_teniesonline(url)
elif mode==500:confirm()
elif mode==501:series.get_xroniaS(url)
#elif mode==501:series.info()
elif mode==806:spor.get_spor(url)
elif mode==807:spor.get_link(url)
elif mode==814:spor.get_embed(url)

elif mode==1000:kids.yousmile()
elif mode==1001:kids.yousmile1(url)
elif mode==1002:kids.yousmile2(name,url)
elif mode==1003:yousmile(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))