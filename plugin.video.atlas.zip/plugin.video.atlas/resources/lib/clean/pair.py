# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import webbrowser

from resources.lib.clean import addon
from resources.lib.clean import openn

def pair():
    openn.addDir('[B][COLOR white]openload[/COLOR][/B]','',809,'https://ww.premiumlinkgenerator.com/data/hosts/openload_large.png',addon.art,'')  
    openn.addDir('[B][COLOR white]Alluc[/COLOR][/B]','',810,'http://alluctv.in/images/alogo.png',addon.art,'')  
    openn.addDir('[B][COLOR white]VideoMe[/COLOR][/B]','',811,'http://www.videomeproductions.co.uk/images/VideoMe-Logo.png',addon.art,'')   
    openn.addDir('[B][COLOR white]Vidupme[/COLOR][/B]','',812,'http://perflix.16mb.com/images/button2.png',addon.art,'')    
    
    
    
    

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()



def alluc():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://accounts.alluc.ee/profile/' ) )
    else:
        opensite = webbrowser . open('https://accounts.alluc.ee/profile/')


def openload():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/pair' ) )
    else:
        opensite = webbrowser . open('https://olpair.com/pair')

def videome():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://thevideo.io/pair' ) )
    else:
        opensite = webbrowser . open('https://thevideo.io/pair')
        
def vidupme():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://vidup.me/pair' ) )
    else:
        opensite = webbrowser . open('https://vidup.me/pair')       