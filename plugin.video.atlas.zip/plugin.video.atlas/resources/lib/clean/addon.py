# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import sys
import os
from t0mm0.common.addon import Addon

addon_id = 'plugin.video.atlas'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
fanart = ADDON.getAddonInfo('FANART')
PATH = 'ATLAS'
VERSION = ADDON.getAddonInfo('version')
Lang        = ADDON.getLocalizedString
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/', 'arrt.jpg'))
userdata_path = xbmc.translatePath('special://userdata/')
database_path = xbmc.translatePath('special://userdata/Database')
addon_data = xbmc.translatePath('special://userdata/addon_data')
thumbnail_path = xbmc.translatePath('special://userdata/Thumbnails')
cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
temp_path = os.path.join(xbmc.translatePath('special://home'), 'temp')
addons_path = os.path.join(xbmc.translatePath('special://home'), 'addons')
packages_path = os.path.join(xbmc.translatePath('special://home/addons'), 'packages')