# -*- coding: utf-8 -*-

def Clean(desc):
    desc = desc.replace('&nbsp;','\'').replace('&hellip;','.').replace('CAM','\'').replace('TS','').replace('&#160;','')
    desc = desc.replace('&#039;','').replace('&quot;','').replace('Για να δείτε την ταινία επιλέξτε έναν από τους 2 πάροχους (HDVID.TV ή Streamcloud.) Εάν','')
    desc = desc.replace('Για να δείτε την ταινία επιλέξτε έναν από τους ακόλουθους παρόχους (HDvid.tv ή Streamcloud) Εάν είστε από κινητό ή tablet σας','') 
    desc = desc.replace('Για να δείτε την ταινία επιλέξτε έναν από τους 2 πάροχους (HDVID.TV ή Streamcloud.)','').replace('&#8220;','').replace('&#8221;','').replace('&#8230;','').replace('&#8211;','') 
    desc = desc.replace('Για να δείτε την ταινία επιλέξτε έναν από τους 3 πάροχους (HDVID.TV.','').replace('<a href=http:////www.greektvseries.com/%CE%B1%CE%BB%CE%AD%CE%BA%CE%BF%CF%82-%CE%B1%CE%BB%CE%B5target= blank','')
    desc = desc.replace('Ατάτα Τίτλου: Για να δείτε την ταινία επιλέξτε έναν από τους ακόλουθους παρόχους (HDvid.tv ή Streamcloud) Εάν','').replace('<span style=font-size: 14pt;','')
    desc = desc.replace(' Για να δείτε την ταινία επιλέξτε έναν από τους ακόλουθους παρόχους (HDvid.tv ή Streamcloud) Εάν είστε','').replace('</span','').replace('<span style=font-size: 12pt;','')
    desc = desc.replace('Για να δείτε την ταινία επιλέξτε έναν από τους 3 πάροχους (HDVID.TV , vidto ή Streamcloud.) Εάν','')
    desc = desc.replace('Για να δείτε την ταινία επιλέξτε έναν από τους 2 πάροχους (HDVID.TV ,','').replace('&#8211;','')
    desc = desc.replace('Για να δείτε την ταινία επιλέξτε έναν από τους ακόλουθους παρόχους (HDvid.tv','').replace('&#8230;','')
    desc = desc.replace('href="','').replace('</a>','').replace('</b>','').replace('</h3>','').replace('<h3>','').replace('</div>','').replace('&#8217;','')
    desc = desc.replace('https://tainia.online/pos-vlepo-tenia/"','').replace(' width="854" height="480"','').replace('frameborder="0" allowfullscreen="allowfullscreen">','').replace('','')
    desc = desc.replace('target="_blank">','').replace('Mu;','').replace('&#160;','').replace('&#124;','').replace('#38;','').replace('&#160;','')
    return desc

def Clean(name):
    name = name.replace('&quot;','').replace('amp;','').replace('<br/>','').replace('amp;','').replace('Synopsis of','')
    name = name.replace('&#39;','').replace('amp;','').replace('<br/>','').replace('&ocirc;','')
    name = name.replace('amp;','').replace('amp;','').replace('&#8211;','').replace('&rsquo;','')
    name = name.replace('<strong>','').replace('</strong>','').replace('amp;','').replace('&frac12;','')
    name = name.replace('<strong>','').replace('</strong>','').replace('"','').replace('&#039;','')
    name = name.replace('&#8230;','').replace('&#8217;','').replace('&#038;','').replace('&#8211;','')
    name = name.replace('<strong>','').replace('</strong>','').replace('&#8211;','').replace('&#038;','')
    name = name.replace('<strong>','').replace('</strong>','').replace('&#8230;','').replace('&#8217;','')
    name = name.replace('&#8230;','').replace('&#8217;','').replace('&#8217;','').replace('&quot;','')
    name = name.replace('rel="noopener external noreferrer" data-wpel-link="external">','').replace('Episode','Επεισοδιο')
    name = name.replace('rel="noopener">','').replace('rel="noopener noreferrer">','').replace('&#8217;','')
    name = name.replace('rel="noopener noreferrer external"','').replace('>','').replace('&#39;','').replace('<br /','')
    name = name.replace('data-wpel-link="external"','').replace('_',' ').replace('.',' ').replace('&#160;','')
    name = name.replace('rel="external noopener noreferrer">','').replace('&#8220;','').replace('&#8221;','')
    name = name.replace('rel="external noopener noreferrer"','').replace('class=external rel=nofollow','')
    name = name.replace('class="external" rel="nofollow">','').replace('<h3><a href="http://ntokimanter.gr/video','')
    name = name.replace('rel="noopener nofollow" class="external">','').replace('rel=noopener nofollow class=external','')
    name = name.replace('rel="noopener noreferrer nofollow" class="external">','').replace('rel=noopener noreferrer nofollow class=external','')
    name = name.replace('target= blank rel=noopener noreferrer','').replace('<strong>','').replace('&#8217;','').replace('&#8230;','').replace('&#038;','')
    return name