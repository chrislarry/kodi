# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import requests

from bs4 import BeautifulSoup
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import addon


#def Spor_menu():
    #openn.addLink('[B][COLOR white]Αγώνες σε επανάληψη[/COLOR][/B]','http://la8osapofash.com',,addon.icon,addon.art,'')

def get_spor(url):
	p = openn.Open_Url(url.encode('utf-8'))
	r = re.compile('<div class="eTitle" style="text-align:left;"><a href="(.+?)">(.+?)</a>.+?<p><img alt="" src="(.+?)" style="width: 150px; height: 100px;" />.+?class="e-comments" href="(.+?)">.+?</a>',re.DOTALL).findall(p)
	for url,name,icon,desc in r:
		url = 'http://la8osapofash.com' + url
		icon = 'http://la8osapofash.com' +icon
		desc = desc.split('/')[3].split('#')[0]
		openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,807,icon,addon.art,desc)
	try:
		m=re.compile('</b> <a class="swchItem" href="(.+?)"').findall(p)[0]
		m = 'http://la8osapofash.com' + m
		openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,806,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
	except:pass
	setView.setView('movies', 'movie-view') 

def get_link(url):
	c = 0
	p = openn.Open_Url(url.encode('utf-8'))
	r = re.compile('<p>.+?<a href="(.+?)">',re.DOTALL).findall(p)
	for url in r:
		if 'http://la8osapofash.com/publ' in url:
			c2 = 'Μετάβαση'
			openn.addDir('[B][COLOR yellow]%s[/COLOR][/B]'%c2,url,807,'https://i.imgur.com/0Exal6r.png',addon.art,'')
		else:
			r2 = re.compile('src="(.+?)"').findall(p)
			for url in r2:
				if 'embed' in url:
					c = c + 1
					c2 = '...Δείτε το εδώ'
					openn.addDir('[B][COLOR white]%s[/COLOR][/B]''[B][COLOR yellow]%s[/COLOR][/B]' %(c,c2),url,200,'https://i.imgur.com/0Exal6r.png',addon.art,'')



					
#################################################################################################################