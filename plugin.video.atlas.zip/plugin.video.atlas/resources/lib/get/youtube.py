# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time

from resources.lib.clean import clean
from resources.lib.clean import openn
from resources.lib.clean import setView
from resources.lib.clean import addon
from resources.lib.modules import plugintools

def Kid_menu():
    openn.addDir('[B][COLOR white]BabyTV Ελληνικά[/COLOR][/B]','https://www.youtube.com/playlist?list=PL7Orgq9K_2UGacpdTRzKVgy_yPirEmItY',1,'https://yt3.ggpht.com/-oE16k6kTALA/AAAAAAAAAAI/AAAAAAAAAAA/9Adqm06bBdQ/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'')
    openn.addDir('[B][COLOR white]Φτιάξε το μόνος σου[/COLOR][/B]','https://www.youtube.com/playlist?list=PLJCjtthapondVeUHV81PanV-uxvirf4_f',1,'https://yt3.ggpht.com/-h5J4CfTWRtw/AAAAAAAAAAI/AAAAAAAAAAA/HB1mm6urpjY/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'')
    openn.addDir('[B][COLOR white]Zouzounia TV[/COLOR][/B]','https://www.youtube.com/playlist?list=PLu5lDW0KA9OMLC4nvaqVYsxHk4VulefvM',1,'https://yt3.ggpht.com/-Vm8ldNGlSZQ/AAAAAAAAAAI/AAAAAAAAAAA/8oHJHdzBRhw/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'')
    openn.addDir('[B][COLOR white]Ελληνικά Παιδικά Τραγούδια[/COLOR][/B]','https://www.youtube.com/playlist?list=PLOpEfV_1HrmFwjvMBq0Z_ObBkEIb7jTxx',1,'https://yt3.ggpht.com/-MNtO5EOJMcU/AAAAAAAAAAI/AAAAAAAAAAA/lR2QqCo90E0/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'')
    openn.addDir('[B][COLOR white]Σαμπρίνα Η Μικρή Μάγισσα[/COLOR][/B]','https://www.youtube.com/playlist?list=PLm7I9S_jFaaBVdKbTxrmPxw0Y03GucLi4',1,'https://i.ytimg.com/vi/N298Jz61PAM/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAV_bjEhv-OPdbPxLj-KkKFNyv_lA',addon.art,'')
    openn.addDir('[B][COLOR white]Παιδικά/Νανουρισματα[/COLOR][/B]','https://www.youtube.com/playlist?list=PLHHUqdEem2zFA-LoLLzTFk3-kG0qvh11o',1,'https://i.ytimg.com/vi/h6B_RHMGWl4/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLBggroLzF-J_XUQ0qFU4Hkab4qUOA',addon.art,'')        
    openn.addDir('[B][COLOR white]Μεταγλωτισμενες[/COLOR][/B]','https://www.youtube.com/playlist?list=PLzUYYLeB25aIalMEK6OG1HTvxvasO6IUb',1,'https://i.ytimg.com/vi/m6CLdAUeJLE/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLBcNBVBqMlnmXJ-3ayPIa4UoMZBOg',addon.art,'')
    openn.addDir('[B][COLOR white]Παιδικές Ταινίες[/COLOR][/B]','https://www.youtube.com/playlist?list=PL4Vd9KHgLUCEcHyK5sNAT1_RetXGSW6PO',1,'https://i.ytimg.com/vi/RmmnCbAZq0E/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLBgZRIfxqxLIbgbtz2CFByi_jnJxw',addon.art,'')
    openn.addDir('[B][COLOR white]Ταινίες Κινουμένων Σχεδίων[/COLOR][/B]','https://www.youtube.com/playlist?list=PL4embSjQsYWn5fcNR0JFRJELJYEnZl_fC',1,'https://i.ytimg.com/vi/4HcOB-hySD4/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLD8mWMoL8igwy0kCRDiYX-g2AC4kQ',addon.art,'')
    openn.addDir('[B][COLOR white]Παραμύθια-Παιδικές ταινίες[/COLOR][/B]','https://www.youtube.com/playlist?list=PLllHQmJEPu2aqaZrzXyjIv4Dqx-XmbH0d',1,'https://i.ytimg.com/vi/7Me_HRYNOac/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLBK-1qOs_tAmW4F-T9rCZAjap-MhA',addon.art,'')
    openn.addDir('[B][COLOR white]Παιδικες Ταινιες[/COLOR][/B]','https://www.youtube.com/playlist?list=PLfSoKYWPB7iukLJxiWXCSo0N2hWCNMiuo',1,'https://i.ytimg.com/vi/GS9KmyBznPg/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLBLcF1gpE5duqnDeSSBlo1U7LCk-A',addon.art,'')
    openn.addDir('[B][COLOR white]Παιδικά παραμύθια[/COLOR][/B]','https://www.youtube.com/playlist?list=PLszjNdunPhYwU7rBOuwUXb9fqj0nob15C',1,'https://i.ytimg.com/vi/7spFVIwARo4/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDqgSpnxKDVHf3GLkHHN10f33WGMQ',addon.art,'')
    openn.addDir('[B][COLOR white]Kαραόκε παιδικό[/COLOR][/B]','https://www.youtube.com/playlist?list=PLL2NERJtzONlDtythkzBjO8I5aMYoknlg',1,'https://i.ytimg.com/vi/0mc4_4rhlCg/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLC7n2VKO1Sc3xxKGD3WMA11h6uL7w',addon.art,'')
    openn.addDir('[B][COLOR white]Πρωινό ξύπνημα[/COLOR][/B]','https://www.youtube.com/playlist?list=PLK6FKSaOVVE-R7sOK5bakjwJQgVI-nJiz',1,'https://i.ytimg.com/vi/sSQnzPzn4hQ/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAa-2Z6S2Hdl-Jn19-3mxAAeMwXzg',addon.art,'')
    openn.addDir('[B][COLOR white]Ροζ Πάνθηρας[/COLOR][/B]','https://www.youtube.com/playlist?list=PLXZxlZJF7a0vop_dMQyBMzdEkYD2o8AVt',1,'https://i.ytimg.com/vi/JiFCRa_iHs8/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLBuZ63_qvRyRzq-YBWelP28lWafdw',addon.art,'')
####################################################################################################################################################################
def diafora():
    openn.addDir('[B][COLOR white]Σεφερλής[/COLOR][/B]','https://www.youtube.com/playlist?list=PL0YGQVj2XPIvnrNpwH_htULZ157DHnAl8',1,'https://i.ytimg.com/vi/evyW6XEc74U/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDBauJEt5zGbI6eLsA4YivE1YjnPA',addon.art,'')
    openn.addDir('[B][COLOR white]Σεφερλής 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PL48F8D3EDB05C98F2',1,'https://i.ytimg.com/vi/3ccVYe3SfYc/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDrFf6CzWXtXFpYil0W2_lcaldanQ',addon.art,'')
    openn.addDir('[B][COLOR white]ΑΜΑΝ[/COLOR][/B]','https://www.youtube.com/playlist?list=PLJDZTRUBzHwNwY810a4hjg4jPLrPpE6TH',1,'https://i.ytimg.com/vi/Y9_caoilYYE/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDU0757XVNZhJ9S1EAjGVr2wrb6lw',addon.art,'')
    openn.addDir('[B][COLOR white]ΑΜΑΝ 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLSjFuYP8TWC_llb81n8pVnwh_fRzUIRG_',1,'https://i.ytimg.com/vi/mNRlZqEo3NQ/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLBhNRWc2gzYOEz89NgcsxU5fv5Mxg',addon.art,'')
    openn.addDir('[B][COLOR white]Ελληνοφρένεια[/COLOR][/B]','https://www.youtube.com/playlist?list=PLxNfXgxZLlU5cD6ekNqCQHI0GcIvomf3e',1,'https://i.ytimg.com/vi/U4sUAp8C3aM/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLA1LEHnvLccIi-wvn71WSKvcj7Ayw',addon.art,'')
    openn.addDir('[B][COLOR white]Ελληνοφρένεια 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLgx_dHoSfyLR2CSxqnFGiLB-oP38a6bf7',1,'https://i.ytimg.com/vi/kxOhU4kltF4/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDHP9HscjiABP5_V5KGB3tNcIkZLA',addon.art,'')
    openn.addDir('[B][COLOR white]Ράδιο αρβύλα ανέκδοτα[/COLOR][/B]','https://www.youtube.com/playlist?list=PL3C0000A92DC31E4C',1,'https://i.ytimg.com/vi/vCppe5dLZOI/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCMwB8GJrHbDDV8bgo-CZOO0C4KUA',addon.art,'')
    openn.addDir('[B][COLOR white]Ράδιο αρβύλα ανέκδοτα 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLys0WD0trdzMSfetzGg9S46qDfxgWP_Sh',1,'https://i.ytimg.com/vi/w58DNZYXmWk/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDyS3EIWzGKxn35oZpFEm-h7OFzHA',addon.art,'')
    openn.addDir('[B][COLOR white]Τάκης Τσουκαλάς[/COLOR][/B]','https://www.youtube.com/playlist?list=PLZevQlR6aZLzRqfrqTndkhaonG7nxR5ug',1,'https://i.ytimg.com/vi/LQxxi9CFMgE/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLB41HB2jY0tf2K9iVzY3R3HLzAT_g',addon.art,'')
    openn.addDir('[B][COLOR white]Τάκης Τσουκαλάς 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLQp_2PmtaGSI2WCsCdUmSNPE-czFXzYv-',1,'https://i.ytimg.com/vi/u0nLqMreGD0/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAw9DLOOQ1IOyynQkFsqnBJ6xNZZg',addon.art,'')
    openn.addDir('[B][COLOR white]Πλάκα κάνεις[/COLOR][/B]','https://www.youtube.com/playlist?list=PLBAPqBY8JoYnwq24XdEAjmKRuzfdCkWY-',1,'https://i.ytimg.com/vi/-70GFKO4M1Y/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAM91wp2OAJQDC9BwlzT8Xma1sA2w',addon.art,'')
    openn.addDir('[B][COLOR white]Πλάκα κάνεις 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLBAPqBY8JoYmbfNVLx686b0_ywdz1b76y',1,'https://i.ytimg.com/vi/X0uD3mRofGg/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLBxGFrKoUDY6nJmCdF1qKgjA4ZZ7A',addon.art,'')
    openn.addDir('[B][COLOR white]Λαζόπουλος ανέκδοτα[/COLOR][/B]','https://www.youtube.com/playlist?list=PLWmAyiGcc7kkHkYPKsmOK6fFNqhMkTpkG',1,'https://i.ytimg.com/vi/cglSGU5nLXI/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLDQdtoPP45cO8IVz2IUsU7xC48g1Q',addon.art,'')
    openn.addDir('[B][COLOR white]Λαζόπουλος ανέκδοτα 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLqYmZR56okhpQdv9QBafib8r4U9SktYoO',1,'https://i.ytimg.com/vi/gh8UW7tkPoI/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAP3xh_gduGgLs9J7wTW1hjPkeYzA',addon.art,'')
    openn.addDir('[B][COLOR white]Just For Laughs Gags[/COLOR][/B]','https://www.youtube.com/playlist?list=PLCuG0s-fh4BE9CaaJ5rJnNvnSSy4vtuEn',1,'https://i.ytimg.com/vi/e4b5F7JBvdw/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAgoA-O68x57irvUncGJELudZwfog',addon.art,'')
    openn.addDir('[B][COLOR white]Just For Laughs Gags 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLSvMPeNDPSIXvhkoT1qb0Ltyb6YpK1eOw',1,'https://i.ytimg.com/vi/9RcoYhgId1g/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCMN0CQ0cbAcJNFGCBn4IOBHzx3eg',addon.art,'')
    openn.addDir('[B][COLOR white]Mr. Bean[/COLOR][/B]','https://www.youtube.com/playlist?list=PLe9kjFJ6bWHhZyRXzwK3XPBqXPSuJSyUp',1,'https://i.ytimg.com/vi/gaKNR181TTk/hqdefault.jpg?sqp=-oaymwEXCNACELwBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLCgJpBxyRQJg7k4bAySPY72-ahGpQ',addon.art,'')
    openn.addDir('[B][COLOR white]Mr. Bean 2[/COLOR][/B]','https://www.youtube.com/playlist?list=PLkzGTr-CDUanXVDqcBoT3Rcazwd-vJNRy',1,'https://i.ytimg.com/vi/6iK0Rbp0BgU/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLAF5KU_AbLED5WtoXlP13Svf2horg',addon.art,'')
    # addDir('','',1,'','','')
    # addDir('','',1,'','','')
    # addDir('','',1,'','','')
######################################################################################################################################################
def Moysik_menou():
    openn.addDir('[B][COLOR white]Κορυφαία κομμάτια - Ελλάδα[/COLOR][/B]','https://www.youtube.com/playlist?list=PLFgquLnL59amLUQzbEhACbArpoHPiymHr',1,'https://yt3.ggpht.com/pHwZj3tkgC3SJFbuqebBoT7WtVcIwAijEmcbe9VDCauv9ZlG6uS2zjvZQUSO7SfFqa3xjYqGp_L4QbM7=s288-nd-c-c0xffffffff-rj-k-no',addon.art,'')
    openn.addDir('[B][COLOR white]Τελευταία βίντεο - Μουσική[/COLOR][/B]','https://www.youtube.com/playlist?list=PLFgquLnL59anUzM6LT23zuQhXyZfg7NPr',1,'https://yt3.ggpht.com/pHwZj3tkgC3SJFbuqebBoT7WtVcIwAijEmcbe9VDCauv9ZlG6uS2zjvZQUSO7SfFqa3xjYqGp_L4QbM7=s288-nd-c-c0xffffffff-rj-k-no',addon.art,'')
    openn.addDir('[B][COLOR white]Κορυφαία κομμάτια -ποπ[/COLOR][/B]','https://www.youtube.com/playlist?list=PLDcnymzs18LWrKzHmzrGH1JzLBqrHi3xQ',1,'https://yt3.ggpht.com/pHwZj3tkgC3SJFbuqebBoT7WtVcIwAijEmcbe9VDCauv9ZlG6uS2zjvZQUSO7SfFqa3xjYqGp_L4QbM7=s288-nd-c-c0xffffffff-rj-k-no',addon.art,'')
    openn.addDir('[B][COLOR white]Κορυφαία κομμάτια -χιπ χοπ[/COLOR][/B]','https://www.youtube.com/playlist?list=PLH6pfBXQXHEC2uDmDy5oi3tHW6X8kZ2Jo',1,'https://yt3.ggpht.com/pHwZj3tkgC3SJFbuqebBoT7WtVcIwAijEmcbe9VDCauv9ZlG6uS2zjvZQUSO7SfFqa3xjYqGp_L4QbM7=s288-nd-c-c0xffffffff-rj-k-no',addon.art,'')
    openn.addDir('[B][COLOR white]RedMusic: BiggestSounds[/COLOR][/B]','https://www.youtube.com/playlist?list=PL3oW2tjiIxvQE4i4Bp7stbkZNGHGitgOf',1,'https://yt3.ggpht.com/-TbrsZdRO_mw/AAAAAAAAAAI/AAAAAAAAAAA/KY-mAQXC6Lo/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'Νέες Κυκλοφορίες 2017-2018: New greek songs (Νέες κυκλοφορίες 2018 νέα Ελληνικά τραγούδια)')
    openn.addDir('[B][COLOR white]Greek Music TOP 40 Songs This Week 2018[/COLOR][/B]','https://www.youtube.com/playlist?list=PLKUA473MWUv088PpZi7SaYcMLp9mDnWn8',1,'https://yt3.ggpht.com/-TbrsZdRO_mw/AAAAAAAAAAI/AAAAAAAAAAA/KY-mAQXC6Lo/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'Τα πιό καινούργια Ελληνικά Τραγούδια 2018')
    openn.addDir('[B][COLOR white]Greek Music Channel[/COLOR][/B]','https://www.youtube.com/channel/UC5G0O182Pfa70I3VgMw6gUQ/playlists',1,'https://yt3.ggpht.com/-mWziBZk9y7Y/AAAAAAAAAAI/AAAAAAAAAAA/e8G6xpENozk/s100-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'')        
    openn.addDir('[B][COLOR white]BEST GREEK KARAOKE[/COLOR][/B]','https://www.youtube.com/playlist?list=PL8Hzavd91o6dMFwk6tmriwOJ__eh-siuV',1,'https://i.ytimg.com/vi/EBrqumQHVMU/hqdefault.jpg?sqp=-oaymwETCHgQWkha8quKqQMHCAEVAACIQg==&rs=AOn4CLC6Zv1oieAicpqzPn11t1_ceJ2haw',addon.art,'')
    openn.addDir('[B][COLOR white]KARAOKE GREEK[/COLOR][/B]','https://www.youtube.com/playlist?list=PLZn1HR5snr07EKLrSVu-GkyiPQxlV_yxu',1,'https://i.ytimg.com/vi/AvIGO-0RqQI/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLAvndrTnF7caZTkmMhpL3tY0gmXog',addon.art,'')        
    openn.addDir('[B][COLOR white]Ελληνικά - Συλλογή[/COLOR][/B]','https://www.youtube.com/playlist?list=PL2SuDufpqr82AGhlzjnLqhMZGanVb5Nj2',1,'https://i.ytimg.com/vi/0ZV0GGOl0go/hqdefault.jpg?sqp=-oaymwETCHgQWkha8quKqQMHCAEVAACIQg==&rs=AOn4CLDYnWeoqP2t5N_DMLzwzsJUkgeUwQ',addon.art,'Έντεχνα/Λαϊκά/Pop/Rock')
    openn.addDir('[B][COLOR white]Έντεχνο & Ροκ Ελληνικό[/COLOR][/B]','https://www.youtube.com/playlist?list=PL12O4GdBoroFiGHLqUfPPRJSIxmzWV06c',1,'https://i.ytimg.com/vi/rEN3MoREC_k/hqdefault.jpg?sqp=-oaymwETCHgQWkha8quKqQMHCAEVAACIQg==&rs=AOn4CLBXSY9KCAN-h_mPkLJT1PHderVBgA',addon.art,'')
    openn.addDir('[B][COLOR white]Vevo[/COLOR][/B]','',458,'https://yt3.ggpht.com/-hmxOepMtptM/AAAAAAAAAAI/AAAAAAAAAAA/nzePQZGAM2Y/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'') 
    openn.addDir('[B][COLOR white]Vh1[/COLOR][/B]','',457,'https://yt3.ggpht.com/-WF6qT32CVUc/AAAAAAAAAAI/AAAAAAAAAAA/KF_jhtLuMl4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,'')

####################################################################################################################################################################
kids2=[
    ("[B][COLOR white]BabyTV Ελληνικά[/COLOR][/B]", "channel/UCm_kb1Qt-gc08BEgHfUmwfA/playlists", 'https://yt3.ggpht.com/-oE16k6kTALA/AAAAAAAAAAI/AAAAAAAAAAA/9Adqm06bBdQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Φτιάξε το μόνος σου[/COLOR][/B]", "channel/UCyWY6NbcKzR9G7bbEBgfLCg/playlists", 'https://yt3.ggpht.com/-h5J4CfTWRtw/AAAAAAAAAAI/AAAAAAAAAAA/HB1mm6urpjY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Zouzounia TV[/COLOR][/B]", "channel/UC9QSJuIBLUT2GbjgKymkTaQ/playlists", 'https://yt3.ggpht.com/-Vm8ldNGlSZQ/AAAAAAAAAAI/AAAAAAAAAAA/8oHJHdzBRhw/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Ελληνικά Παιδικά Τραγούδια[/COLOR][/B]", "channel/UCt5lQhCcAEQhvauv6lkWYCw/playlists", 'https://yt3.ggpht.com/-MNtO5EOJMcU/AAAAAAAAAAI/AAAAAAAAAAA/lR2QqCo90E0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Caddon.artoonTV Greece[/COLOR][/B]", "channel/UCbeqY5Q68NqfzXQz582eRVQ/playlists", 'https://yt3.ggpht.com/-MyE1jhX0KQ0/AAAAAAAAAAI/AAAAAAAAAAA/qAdOC5Q1tmY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]globalakia[/COLOR][/B]", "channel/UCDUk3NKaZwzPEBkCTCKIVig/playlists", 'https://yt3.ggpht.com/-tqUUVTe_9W4/AAAAAAAAAAI/AAAAAAAAAAA/C-v2j8bR63E/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Παίξτε μαζί μου[/COLOR][/B]", "channel/UCODvyPpGXiCMtG0PzcqWXcw", 'https://yt3.ggpht.com/-K3bu-S6HRNU/AAAAAAAAAAI/AAAAAAAAAAA/pPwhnZOEEOY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Παιδικό Κανάλι[/COLOR][/B]", "channel/UCp_UGBizEZEoHJlS71ninSA/playlists", 'https://yt3.ggpht.com/-1El1TLf3hlg/AAAAAAAAAAI/AAAAAAAAAAA/hUoR927dsaE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Εναλλακτικό Κύκλος,[/COLOR][/B]", "channel/UC2gY3IDokowhZfuOqPKpzAw/playlists", 'https://yt3.ggpht.com/-fRGRfxpHJFM/AAAAAAAAAAI/AAAAAAAAAAA/Zbl9j-YyMUA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Δήλος TV Παιδικό Κανάλι[/COLOR][/B]", "channel/UCwhq1p1Zvc2HylxSKmjmaLg/playlists", 'https://yt3.ggpht.com/-77UYoFnIBOo/AAAAAAAAAAI/AAAAAAAAAAA/ltVSmmjb2Yo/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Πειραχτήρια TV[/COLOR][/B]", "channel/UCnIEDKNRPQAsxU8gu0QqkaQ/playlists", 'https://yt3.ggpht.com/-tS9HnznNzaE/AAAAAAAAAAI/AAAAAAAAAAA/NaBbviI2fOk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art)
]

def kids1(params):
    for name, id, icon, fanart in kids2:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
######################################################################################################################################
video=[
    ("[B][COLOR white]Σεφερλής Official[/COLOR][/B]", "channel/UCy67kUJlbfrJ6aNkEhMVyig/playlists", 'https://yt3.ggpht.com/-aY-6CVVFVZI/AAAAAAAAAAI/AAAAAAAAAAA/dAWkmk5HjAY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art,),
    ("[B][COLOR white]Ελληνοφρένεια Official[/COLOR][/B]", "channel/UCJHTZ8VwrSdDehq51KfbTxg/playlists", 'https://yt3.ggpht.com/-w6IbbT-eLkE/AAAAAAAAAAI/AAAAAAAAAAA/gdKSzGZ9ZGI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Ράδιο αρβύλα Official[/COLOR][/B]", "channel/UCq1mODT_hvZS6YupcS1L1dw/playlists", 'https://yt3.ggpht.com/-LespYNDA6Z4/AAAAAAAAAAI/AAAAAAAAAAA/7JDTDD2rmAg/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Άντε Γειά Official[/COLOR][/B]", "channel/UCrAOuO8iYCDqemWDkm1pDmg/playlists", 'https://yt3.ggpht.com/-VUT1_SmH0Kc/AAAAAAAAAAI/AAAAAAAAAAA/T13gv7l2pJU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Ευτύχης Μπλέτσας Official[/COLOR][/B]", "channel/UCVO2_vAXqk-84iByks7GvaA/playlists", 'https://yt3.ggpht.com/-z2bkE7_gkjI/AAAAAAAAAAI/AAAAAAAAAAA/W2gI9WvCfF4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Η κουζίνα του Ευτύχη Official[/COLOR][/B]", "channel/UCiSvxknl08ngPffdWtoUi7Q/playlists", 'https://yt3.ggpht.com/-TIrxP0EaUGY/AAAAAAAAAAI/AAAAAAAAAAA/0Fo_y5DmkR4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),  
    ("[B][COLOR white]TheCookgr Official[/COLOR][/B]", "channel/UC_ekKKUFIctiMUnf7eK_HoA/playlists", 'https://yt3.ggpht.com/-nemFNrW3heE/AAAAAAAAAAI/AAAAAAAAAAA/GhceXHzaQcs/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Kitchen Lab! Official[/COLOR][/B]", "channel/UC9DGkZrmvWPk-yqLawxTcfQ/playlists", 'https://yt3.ggpht.com/-hRyYdOeCeA0/AAAAAAAAAAI/AAAAAAAAAAA/2eJVXCit4SE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Dolmadaki gr Official[/COLOR][/B]", "channel/UCbyhSwWr22Yl8vmiQkbLZJA/playlists", 'https://yt3.ggpht.com/-koc9lCefFA0/AAAAAAAAAAI/AAAAAAAAAAA/JN990lQi3m0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Paxxi Official[/COLOR][/B]", "channel/UC1LT80W3m0JCPj5kIaB_E9A/playlists", 'https://yt3.ggpht.com/-dXO3I1hcqe8/AAAAAAAAAAI/AAAAAAAAAAA/wcjUVVvolCU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Φαγητά & γλυκά Official[/COLOR][/B]", "channel/UCJEnSm24i0CZ3iseQlklFYw/playlists", 'https://yt3.ggpht.com/-6j707R6c23Q/AAAAAAAAAAI/AAAAAAAAAAA/0n5FdWK1_l8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Vissarion Paddon.arthenis Official[/COLOR][/B]", "channel/UCx_dfbOjaWH7hZSUPWmFStA/playlists", 'https://yt3.ggpht.com/-1uWGQbnusR8/AAAAAAAAAAI/AAAAAAAAAAA/HuMHbPkwN3U/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Just For Laughs Gags Official[/COLOR][/B]", "channel/UCpsSadsgX_Qk9i6i_bJoUwQ/playlists", 'https://yt3.ggpht.com/-yNspfCq56dQ/AAAAAAAAAAI/AAAAAAAAAAA/il9bnycTmHI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Hidden Camera Classics Official[/COLOR][/B]", "channel/UCmBvQYdo2Y_yAhIe_gBwAww/playlists", 'https://yt3.ggpht.com/-XYNId5jSgok/AAAAAAAAAAI/AAAAAAAAAAA/2OWBLvf-m_Q/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Mr. Bean Official[/COLOR][/B]", "channel/UCkAGrHCLFmlK3H2kd6isipg/playlists", 'https://yt3.ggpht.com/-FvBjR0DHn0c/AAAAAAAAAAI/AAAAAAAAAAA/1X7Fl-w2PUw/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    # ("[B][COLOR white][/COLOR][/B]", "", ''),
    # ("[B][COLOR white][/COLOR][/B]", "", '')          
]

def kdiafora(params):
    for name, id, icon, fanart in video:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
############################################################################################################################################
omades=[
    ("[B][COLOR white]" +addon.Lang(32056).encode('utf-8')+ "[/COLOR][/B]", "channel/UC1Y2wf1sefOhOqUEGiesujQ", 'https://yt3.ggpht.com/-AZ5MqY8sIW0/AAAAAAAAAAI/AAAAAAAAAAA/ddImBE3Qpow/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32057).encode('utf-8')+ "[/COLOR][/B]", "channel/UCLf7YXb-0PWEeq59Z_q318A", 'https://yt3.ggpht.com/-tTmFALe33tk/AAAAAAAAAAI/AAAAAAAAAAA/tJagWYfd0OA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32058).encode('utf-8')+ "[/COLOR][/B]", "channel/UCX8HprRO1BYnQ6Mu2nB9VsQ", 'https://yt3.ggpht.com/-Ey5wzET4rvI/AAAAAAAAAAI/AAAAAAAAAAA/ZsS8d2uPvzM/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32059).encode('utf-8')+ "[/COLOR][/B]", "channel/UCInZnZ8JYwmIvs8gtNriwSQ", 'https://yt3.ggpht.com/-lXFr23svM94/AAAAAAAAAAI/AAAAAAAAAAA/3Yw3dk0Jxx0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32060).encode('utf-8')+ "[/COLOR][/B]", "channel/UCvDGYaeFq9sBdj0cGnZ_Uhg", 'https://yt3.ggpht.com/-V8ftvCyHaVI/AAAAAAAAAAI/AAAAAAAAAAA/wLRzLFMql_Y/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32061).encode('utf-8')+ "[/COLOR][/B]", "channel/UC-xFpFhB1fiAa3jZE51gBLA", 'https://yt3.ggpht.com/-799Tw1dd-cs/AAAAAAAAAAI/AAAAAAAAAAA/_dL2fGGURXs/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),        
    ("[B][COLOR white]" +addon.Lang(32062).encode('utf-8')+ "[/COLOR][/B]", "channel/UCbGAOY8tnarNw6T0pHghleg", 'https://yt3.ggpht.com/-BzkVz6FT7rA/AAAAAAAAAAI/AAAAAAAAAAA/QtU7i6zGYks/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32063).encode('utf-8')+ "[/COLOR][/B]", "channel/UCbv8oofgvLZ1B24N6uJ9q6g", 'https://yt3.ggpht.com/-V7fo2ryDyBU/AAAAAAAAAAI/AAAAAAAAAAA/qDqQZP4VvUU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32064).encode('utf-8')+ "[/COLOR][/B]", "channel/UC7pgxTKt5ER_5B6Eab-vffQ", 'https://yt3.ggpht.com/-yWJPg-qy7MM/AAAAAAAAAAI/AAAAAAAAAAA/ssMffOZOkBI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32065).encode('utf-8')+ "[/COLOR][/B]", "channel/UCOiz2y-SJVTnul6LARU9qcQ", 'https://yt3.ggpht.com/-w_jx9FQLk7c/AAAAAAAAAAI/AAAAAAAAAAA/SzDZsp-sqjU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32066).encode('utf-8')+ "[/COLOR][/B]", "channel/UCHobbDB62x0CeGtEny0KB5Q", 'https://yt3.ggpht.com/-KVtk-V-St9w/AAAAAAAAAAI/AAAAAAAAAAA/qo8dHNtkyY8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art)
]

def komades(params):
    for name, id, icon, fanart in omades:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
##############################################################################################################################################################################
ntokimanter=[
    ("[B][COLOR white]" +addon.Lang(32003).encode('utf-8')+ "[/COLOR][/B]", "channel/UCJDIW8e_J_bkFT5rcPvIe2w/playlists", 'https://www.18ano.gr/wp-content/uploads/2016/06/ntokimanter.jpg',addon.art),
    ("[B][COLOR white]" +addon.Lang(32003).encode('utf-8')+ "[/COLOR][/B]", "channel/UCZBqKiX-Qnp7FpzOLEw3V4A/playlists", 'https://yt3.ggpht.com/-gpHzWZ2x7Tk/AAAAAAAAAAI/AAAAAAAAAAA/htd_ppKnSfs/s176-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),    
    ("[B][COLOR white]Cosmos Greek Documentaries[/COLOR][/B]", "channel/UCAv_XZUa_qItspsAiZK8bQg", 'https://yt3.ggpht.com/-ecpSFFu8Enc/AAAAAAAAAAI/AAAAAAAAAAA/jQ01dprZPMw/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]Δήλος TV Ντοκιμαντέρ[/COLOR][/B]", "channel/UCoXSBSuwF7AO2hOXV8bF_Bw/playlists", 'https://yt3.ggpht.com/-Cg0oguJWAaQ/AAAAAAAAAAI/AAAAAAAAAAA/y7iPyVV0ma8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art),
    ("[B][COLOR white]HISTORYofGREECE[/COLOR][/B]", "channel/UCf4bWmtMhlw-OZDRZ4sW0xA", 'https://yt3.ggpht.com/-8F-DUbvdiwg/AAAAAAAAAAI/AAAAAAAAAAA/db37gCdqqN4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg',addon.art)
]

def youtube(params):
    for name, id, icon, fanart in ntokimanter:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
#####################################################################################################################################################
trailers=[
        ("[B][COLOR white]Προσεχώς on Village[/COLOR][/B]", "playlist/PL2rB3_wxnzkTO_w5pyoB_zJWnvi0Sg73q", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
        ("[B][COLOR white]Mix[/COLOR][/B]", "playlist/UUWs6goyS_DHeCq80zaMmEcw", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
        ("[B][COLOR white]On air now[/COLOR][/B]", "playlist/PL2rB3_wxnzkQUB_zKFCdHLPFE_J-a_0Gz", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
        ("[B][COLOR white]Disney trailers[/COLOR][/B]", "playlist/PL13WwxPnV152MDmEYKeXx4FbR-1X8vIgX", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
        ("[B][COLOR white]Marvel trailers[/COLOR][/B]", "playlist/PL13WwxPnV152PfTIydoH36xUm85n6Zv6u", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
        ("[B][COLOR white]pixar trailers[/COLOR][/B]", "playlist/PL13WwxPnV153iSrVa5y7s3NPnz6xxywEy", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
        ("[B][COLOR white]Trailers from feelgood[/COLOR][/B]", "playlist/UUXNcKZ9Wqa0UF0PAf4eu7sw", 'http://koditips.com/wp-content/uploads/hd-movie-trailers-kodi.jpg',addon.art),
]

def GRtrailers(params):
    for name, id, icon, fanart in trailers:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
###########################################################################################################################################################
def run():
    plugintools.log("youtubeAddon.run")
    

    params = plugintools.get_params()
    
    if params.get("action") is None:
        you_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def you_list(params):
    plugintools.log("youtubeAddon.you_list "+repr(params))        

def get_content1(url):
        p = openn.Open_Url(url)
        m = re.compile('tr class=".+?".+?data-title="(.+?)">.+?<a href="(.+?)"',re.DOTALL).findall(p)
        for name,url in m:
            url = 'https://www.youtube.com' + url
            name = name.split('data-video-id="')[0]
            name = name.split('data-set-video-id="')[0]
            name = clean.Clean(name)
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,addon.icon,addon.art,'')   

def GETSOURCES3(url):
        p = openn.Open_Url(url)
        m=re.compile('class=".+?"><a href="(.+?)" class=".+?" aria-hidden=".+?"  data-sessionlink=".+?" >').findall(p)
        for url in m:
            url = 'https://www.youtube.com' + url
            if urlresolver.HostedMediaFile(url).valid_url():
                    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,addon.icon,addon.art,'')            
        setView.setView('movies', 'movie-view') 
#####################################################################################################################################################
def vevo(url):
    plugintools.add_item( 
        #action="", 
        title="Vevo",
        url="plugin://plugin.video.youtube/user/VEVO/",
        thumbnail="https://yt3.ggpht.com/-hmxOepMtptM/AAAAAAAAAAI/AAAAAAAAAAA/nzePQZGAM2Y/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        plot="Music channel vevo " ,
        folder=True )

def vh1(url):
    plugintools.add_item( 
        #action="", 
        title="Vh1 ",
        url="plugin://plugin.video.youtube/user/VH1/",
        thumbnail="https://yt3.ggpht.com/-WF6qT32CVUc/AAAAAAAAAAI/AAAAAAAAAAA/KF_jhtLuMl4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        plot="Music channel" ,
        folder=True )
