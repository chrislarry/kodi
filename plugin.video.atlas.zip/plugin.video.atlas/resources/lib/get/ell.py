# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import requests
import pyxbmct

from bs4 import BeautifulSoup
from resources.lib.clean import clean
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import addon

def ell():
	openn.addDir('[B][COLOR blue]' +addon.Lang(32099).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/',42,'https://i2.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/ou.jpg?resize=1024%2C1024',addon.art,'')
	openn.addDir('[B][COLOR blue]' +addon.Lang(32041).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/',35,'https://i2.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/ou.jpg?resize=1024%2C1024',addon.art,'')
	openn.addDir('[B][COLOR red]' +addon.Lang(32010).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/',94,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'Αναζτητηση για σειρες(ΟΧΙ ΤΑΙΝΙΑΣ...!ΣΗΜΑΝΤΙΚΟ...!)')   
	openn.addDir('[B][COLOR blue]' +addon.Lang(32042).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/ταινίες',38,'https://i0.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/720_9b792c5b5101c4681015e1de3f7ad006.jpg?resize=1024%2C1024',addon.art,'')
	openn.addDir('[B][COLOR blue]' +addon.Lang(32043).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/',39,'https://i0.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/720_9b792c5b5101c4681015e1de3f7ad006.jpg?resize=1024%2C1024',addon.art,'')
	openn.addDir('[B][COLOR red]' +addon.Lang(32011).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/',95,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'Αναζτητηση για ταινιες(ΟΧΙ ΣΕΙΡΑΣ...!ΣΗΜΑΝΤΙΚΟ...!)')
	openn.addDir('[B][COLOR blue]' +addon.Lang(32044).encode('utf-8')+ '[/COLOR][/B]','http://www.greektvseries.com/',88,'https://i0.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/720_9b792c5b5101c4681015e1de3f7ad006.jpg?resize=1024%2C1024',addon.art,'')

def getell(url):
	r = requests.get(url)
	soup = BeautifulSoup(r.content, "html.parser")
	for a in soup.findAll('p', style="text-align: center;"):
	    for i in a.findAll('a'):
	        url = i['href']
	        url = 'https:' + url
	        name = i.text.encode('utf-8')
	        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'
	        	%name,url,37,'https://i2.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/ou.jpg?resize=1024%2C1024',addon.art,'') 


def getell2(url):
	r = requests.get(url)
	soup = BeautifulSoup(r.content, "html.parser")
	for a in soup.findAll('div', id="content"):
	    for i in a.findAll('b'):#[-1:]:
	        desc = i.next.next.encode('utf-8')
	    for u in a.findAll('a'):
	        url = u['href']
	        name2 = u.text.encode('utf-8')
	        if 'Playlist' not in name2:
	            if 'retrodb' not in url:
	                if 'greektvseries' not in url:
	                    for g in a.findAll('img'):
	                        icon = g['src']
	                        if 'https:' not in icon:
	                        	icon = 'https:' + icon
	                        elif 'https:' in icon:
	                        	icon = icon
	                        c = 'Επεισόδιο...'
	                    	t = '***Περίληψη***'
	                    	openn.addDir('[B][COLOR white]%s[/COLOR][/B]''[B][COLOR white]%s[/COLOR][/B]' %(c,name2),url,200,icon,addon.art,'[B][COLOR green]%s[/COLOR][/B]''\n%s' %(t,desc))
	class MyWindow(pyxbmct.AddonDialogWindow):

	    def __init__(self, title=''):
	        super(MyWindow, self).__init__(title)
	        self.setGeometry(700, 500, 5, 2)
	        self.set_controls()
	        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

	    def set_controls(self):
	        image = pyxbmct.Image(icon)
	        self.placeControl(image, 0, 0, 4, 1)
	        self.textbox = pyxbmct.TextBox()
	        self.placeControl(self.textbox, 0, 1, 4, 1)
	        self.textbox.setText('[B][COLOR green]%s[/COLOR][/B]''\n''%s' %(t,desc))
	        self.textbox.autoScroll(4000, 4000, 5000)
	        self.close_button = pyxbmct.Button('[B][COLOR white]Κλείσε για Επεισόδια[/COLOR][/B]''\n''(Return σε Android)')
	        self.placeControl(self.close_button, 4, 0)
	        self.connect(self.close_button, self.close)

	    def setAnimation(self, control):
	    	control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])

	window = MyWindow('Επεισόδια...''[B][COLOR white]%s[/COLOR][/B]'%(name2))
	window.doModal()
	del window      
	setView.setView('movies', 'movie-view')

def getell3(url):
	r = requests.get(url)
	soup = BeautifulSoup(r.content, "html.parser")
	for a in soup.findAll('p', style="text-align: center;"):
	    for i in a.findAll('a'):
	        url = i['href']
	        url = 'https:' + url
	        name = i.text.encode('utf-8')
	        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'
	        %name,url,41,'https://i0.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/720_9b792c5b5101c4681015e1de3f7ad006.jpg?resize=1024%2C1024'
	        ,addon.art,'')    

def getell4(url):
	r = requests.get(url)
	soup = BeautifulSoup(r.content, "html.parser")
	div = soup.find('div', class_='page-content')
	div1 = div.select('b')[-1:]
	for a in div1:
	    desc = a.next.next.encode('utf-8')
	    div2 = div.select('p')[1]
	    for i in div2:
	    	icon = i.get('src')
	    	if 'https:' not in icon:
	    		icon = 'https:' + icon
	    	elif 'https:' in icon:
    			icon = icon
    		div3 = div.select('a')
	    	for u in div3:
	    		url = u.get('href')
	    		if 'http:' in url:
	    			if 'retrodb.gr' not in url:
	    				div5 = div.select('b')[1]
	    				for e in div5:
	    					etos = e.next.encode('utf-8')
	    					c = ' -Year-'
	    					t = '***Περίληψη***'
	    					openn.addDir('%s' '[B][COLOR green]%s[/COLOR][/B]' '[B][COLOR orange]%s[/COLOR][/B]' %('link',c,etos),url,200,icon,addon.art,'[B][COLOR green]\n%s[/COLOR][/B]''\n%s' %(t,desc))
	class MyWindow(pyxbmct.AddonDialogWindow):

	    def __init__(self, title=''):
	        super(MyWindow, self).__init__(title)
	        self.setGeometry(700, 500, 5, 2)
	        self.set_controls()
	        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

	    def set_controls(self):
	        image = pyxbmct.Image(icon)
	        self.placeControl(image, 0, 0, 4, 1)
	        self.textbox = pyxbmct.TextBox()
	        self.placeControl(self.textbox, 0, 1, 4, 1)
	        self.textbox.setText('[B][COLOR green]%s[/COLOR][/B]''\n''%s' %(t,desc))
	        self.textbox.autoScroll(4000, 4000, 5000)
	        self.close_button = pyxbmct.Button('[B][COLOR white]Κλείσε για link[/COLOR][/B]''\n''(Return σε Android)')
	        self.placeControl(self.close_button, 4, 0)
	        self.connect(self.close_button, self.close)

	    def setAnimation(self, control):
	    	control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])

	window = MyWindow('[B][COLOR green]%s[/COLOR][/B]' '[B][COLOR orange]%s[/COLOR][/B]' %(c,etos))
	window.doModal()
	del window  
	setView.setView('movies', 'movie-view')

def katigoriaell(url):#Seires
	r = requests.get (url)
	soup = BeautifulSoup (r.content, "html.parser")
	for a in soup.findAll('ul')[4]:
		name = a.a.text.encode('utf-8')
		url = a.a["href"]
		url = 'http:' + url
		openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,36,addon.icon,addon.art,'')

def katigoriaell2(url):#tainies
	r = requests.get (url)
	soup = BeautifulSoup (r.content, "html.parser")
	for a in soup.findAll('ul')[7]:
	    name = a.a.text.encode('utf-8')
	    url = a.a["href"]
	    url = 'http:' + url
	    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,40,addon.icon,addon.art,'')
                                                                                                                                                                                                                                                
def katigoriaell3(url):#xronologia
	r = requests.get (url)
	soup = BeautifulSoup (r.content, "html.parser")
	for a in soup.findAll('ul')[8]:
	    name = a.a.text.encode('utf-8')
	    url = a.a["href"]
	    url = 'http:' + url
	    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,40,addon.icon,addon.art,'')


def katigoriaell4(url):#filmogriafies
	r = requests.get(url)
	soup = BeautifulSoup(r.content, "html.parser")
	for a in soup.findAll('ul')[9]:
	    name = a.a.text.encode('utf-8')
	    url = a.a["href"]
	    url = 'http:' + url
	    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,89,'https://i0.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/720_9b792c5b5101c4681015e1de3f7ad006.jpg?resize=1024%2C1024'
        ,addon.art,'')

def katigoriaell5(url):
	r = requests.get (url)
	soup = BeautifulSoup (r.content, "html.parser")
	div = soup.find(id="wrapper")
	div1 = div.findAll('a')
	for a in div1:
	    p = div.find ('p', style='text-align: center;')
	    desc = p.text.encode('utf-8')
	    img = div.find('img')
	    icon = img["src"]
	    if 'https:' not in icon:
	    	icon = 'https:' + icon
	    elif 'https:' in icon:
	    	icon = icon
	    name = a.text.encode('utf-8')
	    url = a["href"]
	    url = 'http:' + url
	    if 'ce%b1' in url:
	    	openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,41,icon,addon.art,desc)
	setView.setView('movies', 'movie-view')

def getellnew(url):
	r = requests.get(url)
	soup = BeautifulSoup(r.content, "html.parser")
	div = soup.find('div', class_='vc_tta-panel-body')
	for a in soup.findAll('ul')[5]:
	    url = a.a['href']
	    url = 'http:' + url
	    name = a.a.text.encode('utf-8')
	    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,37,'https://i2.wp.com/www.greektvseries.com/wp-content/uploads/2017/03/ou.jpg?resize=1024%2C1024',addon.art,'')

def Search4():
		keyb = xbmc.Keyboard('', 'Search')
		keyb.doModal()
		if (keyb.isConfirmed()):
			search = keyb.getText().replace(' ','+')
			url = 'http://www.greektvseries.com/?s=' + search
			getell3(url)
		else: return        

def Search5():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'http://www.greektvseries.com/?s=' + search
                getell(url)
        else: return  


######################################################################################################################
# def katigori(url):
# 	r = requests.get(url)
# 	soup = BeautifulSoup(r.content, "html.parser")
# 	div = soup.find(id="wrapper")
# 	div1 = div.findAll('li')
# 	for a in div1:
# 	    name = a.a.img.get('alt').encode('utf-8')
# 	    url = a.a['href']
# 	    icon = a.a.img['src']
# 	    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,803,icon,addon.art,'')#katigories

# def greektube(url):
# 	r = requests.get(url)
# 	soup = BeautifulSoup(r.content, "html.parser")
# 	div = soup.find(id="wrapper")
# 	div1 = div.findAll('div', class_='pm-li-video')
# 	for a in div1:
# 	    name = a.a.img.get('alt').encode('utf-8')
# 	    url = a.a['href']
# 	    icon = a.a.img['src']
# 	    openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,350,icon,addon.art,'')#tube


# def link(url):
# 	r = requests.get(url)
# 	soup = BeautifulSoup(r.content, "html.parser")
# 	div = soup.find(id="wrapper")
# 	div1 = div.findAll('meta')
# 	for a in div1:
# 	    url = a["content"]
# 	    if 'embed' in url:
# 	        openn.addDir('link',url,'','',addon.art,'')#link

