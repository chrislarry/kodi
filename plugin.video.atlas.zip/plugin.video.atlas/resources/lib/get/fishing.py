# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import  base64

from resources.lib.clean import addon
from resources.lib.modules import plugintools

def fishing(url):

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1zb3Rvc3Zhc2lbL0NPTE9SXVtDT0xPUiBncmVlbl0jI1svQ09MT1Jd'),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci9zb3Rvc3Zhc2kv'),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy1tVVBsWmNWMy1aNC9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS93blp1Z3dYOUM4VS9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        plot="Αυτό το κανάλι είναι αφιερωμένο στη θάλασσα και στο ψάρεμα!Ελπίζω να το απολαύσετε οσο και 'γω..",
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1Cb2F0RmlzaGluZ0dyWy9DT0xPUl1bQ09MT1IgZ3JlZW5dIyNbL0NPTE9SXQ=='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci9Cb2F0RmlzaGluZ0dyLw=='),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy1mRkk0OVVjbVZtdy9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS84QlBFUWlJVHA2ay9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        plot="Το περιοδικό Boat & Fishing είναι ένα νέο έντυπο για το ψάρεμα και το σκάφος το οποίο κυκλοφορεί κάθε μήνα με πλούσια ύλη για όλες τις τεχνικές ψαρέματος ερασιτεχνικής αλιείας, τόσο από το σκάφος όσο και από την ακτή. Δοκιμές σκαφών, παρουσιάσεις κινητήρων, νέα προϊόντα και τεχνικά θέματα ολοκληρώνουν την ύλη του Boat & Fishing χαρίζοντας ενημέρωση, γνώση και ψυχαγωγία.",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1TYXZ2YXMgR2lhbSBmaXNoaW5nWy9DT0xPUl1bQ09MT1IgZ3JlZW5dIyNbL0NPTE9SXQ=='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci92YXZ2YXMzLw=='),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy1VWDFwSjJWdGphay9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS9oNXFnaXh1SWl6OC9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        plot="(fishing channel) ΕΡΑΣΙΤΕΧΝΙΚΗ ΑΛΙΕΙΑ...",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1TdGFLb3UgRmlzaGluZ1svQ09MT1JdW0NPTE9SIGdyZWVuXSMjWy9DT0xPUl0='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci9wYXBhZGFraXMxOTY2Lw=='),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy1CMjNtZTg3eXpUTS9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS83a3k3cmJvUWJOWS9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        plot="Fishing Tips",
        folder=True )       

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1UaGFsYXNzYU1lZGlhWy9DT0xPUl1bQ09MT1IgZ3JlZW5dIyNbL0NPTE9SXQ=='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci9UaGFsYXNzYU1lZGlhLw=='),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy13bG56aWFIZGhORS9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS9KRTFxSGRiTVItMC9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        plot="Το ThalassaMedia είναι το κανάλι των εκδόσεων Thalassa, της εταιρίας που εκδίδει τα περιοδικά Thalassa, Thalassa RIB και Ψαρεύω, καθώς και μία σειρά εξειδικευμένων εκδόσεων με αντικείμενο τα ταξίδια με σκάφος, το ψάρεμα, το υποβρύχιο ψάρεμα κ.ά.Το κανάλι της ThalassaMedia φιλοξενεί τα video των περιοδικών της εταιρίας, τα οποία αφορούν σε μια πλούσια θεματολογία καταχωρημένα σε ενότητες, ώστε να διευκολύνουν τους χρήστες του διαδικτύου, αλλά και νέα video των συνεργατών του thalassamedia portal.",
        folder=True )       

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1GaXNoaW5nIFBvaW50IFN5cm9zWy9DT0xPUl1bQ09MT1IgZ3JlZW5dIyNbL0NPTE9SXQ=='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvY2hhbm5lbC9VQ01MdFdnYktJSkFIWXUtREpteGJ0aVEv'),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy1ZMmE4dkFIOHcyTS9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS9NbHlVbkZ0SnJUVS9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        plot="Η μεγαλη μου λατρεια απο τα παιδικα μου χρονια ειναι το ψαρεμα και ειμαι απο τους λιγους τυχερους στην ζωη που καταφεραν και εκαναν το χομπι τους επαγγελμα.Στις 1 Νοεμβριου 2013 εγινα ιδιοκτητης του πρωην Captain Hook Συρου, που στα χερια μου μετονομαστηκε σε Fishing Point Syros.Σε αυτο το καναλι μοιραζομαι προσωπικα βιντεο απο ψαρεματα δικα μου και φιλων.",
        folder=True )       

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV3Oo86xz4HOsc69z4TOv8+Azr/Phc67zr/PgiBGaXNoaW5nWy9DT0xPUl1bQ09MT1IgZ3JlZW5dIyNbL0NPTE9SXQ=='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvY2hhbm5lbC9VQ0tua0gxdnRVWUZKbDloVjBkQzE3dHcv'),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy14bExJd3p4ZTlBOC9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS9FOU1oalJIWmNGWS9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        plot="Πατέντες, τεχνικές, κατασκευές και ότι αφορά το ψάρεμα θα τα βρείτε εδώ ",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1EZW5uaXMgQXJneXJvc1svQ09MT1JdW0NPTE9SIGdyZWVuXSMjWy9DT0xPUl0='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci90aGlvc2FraXMv'),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy0zYnJBcGR3bllHSS9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS8wMWV3TlcwV0xfSS9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        plot="Videakia me psaremata apo tin ameriki k tin ellada otan katebeno",
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title=base64.b64decode('W0NPTE9SIGdyZWVuXSMjWy9DT0xPUl1bQ09MT1IgYmx1ZV1rb25zdGFudGlub3MxMTEwMFsvQ09MT1JdW0NPTE9SIGdyZWVuXSMjWy9DT0xPUl0='),
        url=base64.b64decode('cGx1Z2luOi8vcGx1Z2luLnZpZGVvLnlvdXR1YmUvdXNlci9rb25zdGFudGlub3MxMTEwMC8='),
        thumbnail=base64.b64decode('aHR0cHM6Ly95dDMuZ2dwaHQuY29tLy1GV0REdFNpUHIwQS9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS9LeGo5UFkydHVUOC9zMTAwLWMtay1uby1tby1yai1jMHhmZmZmZmYvcGhvdG8uanBn'),
        plot="Videakia me psaremata",
        fanart=base64.b64decode('c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5maXNoaW5nR1IvZmFuYXJ0LmpwZw=='),
        folder=True )           