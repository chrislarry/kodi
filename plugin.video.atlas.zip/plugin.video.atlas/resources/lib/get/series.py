# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import requests
import pyxbmct

from pyxbmct.addonwindow import *
from bs4 import BeautifulSoup
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import clean
from resources.lib.clean import addon

def SHOWS(url):
    dialog = xbmcgui.Dialog()
    funcs = (vidoza,vidto,openload,get_contS)
    call = dialog.select('ATLAS:',
        ['[B][COLOR white]' +addon.Lang(32045).encode('utf-8')+ '[B][COLOR green]vidoza[/COLOR][/B]',
        '[B][COLOR white]' +addon.Lang(32046).encode('utf-8')+ '[B][COLOR green]vidto[/COLOR][/B]',
        '[B][COLOR white]' +addon.Lang(32046).encode('utf-8')+ '[B][COLOR green]openload[/COLOR][/B]'])
    func = funcs[call]
    return func(url)

def get_xroniaS(url):
    p = openn.Open_Url('http://tainies4k.online/tvshows/')
    r = re.compile('<ul class="scrolling" style="max-height: 300px;">(.+?)</ul>',re.DOTALL).findall(p)
    r2 = re.compile('<li><a href="(.+?)" data-wpel-link="internal">(.+?)</a></li>',re.DOTALL).findall(str(r))[50:]
    for url,name in r2:
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,24,'https://i.imgur.com/Mveo2KC.png',addon.art,'')


def get_contS(url):
    p = openn.Open_Url(url)
    m=re.compile('class="item">.+?<a href="(.+?)" data-wpel-link="internal">.+?class="image">.+?<img src="(.+?)" alt="(.+?)" width="100%" height="100%" />.+?<span class="ttx">(.+?)<div class="degradado">.+?class="dato">(.+?)<b>(.+?)</b>.+?<span class="year">(.+?)</span>'
    ,re.DOTALL).findall(p)
    for url,icon,name,desc,name2,rat,year in m:
        if '/ ' in name:
            name = name.split('/ ')[1]
        year = '[B][COLOR white]([/COLOR]'+ year +'[B][COLOR white])[/COLOR]'
        name = clean.Clean(name)
        desc = clean.Clean(desc)
        t = '***Περίληψη***'
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]  [B][COLOR green]%s[/COLOR][/B] [B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B]'%(name,year,name2,rat),url,83,icon,addon.art,'[B][COLOR green]\n%s[/COLOR][/B]''%s' %(t,desc))
    try:
        r=re.compile('<div class="pag_b"><a href="(.+?)" data-wpel-link="internal">Επόμενη</a></div>').findall(p)[0]
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]'
        ,r,24,'http://i.imgur.com/rKSs0yq.png'
        ,addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass 
    setView.setView('movies', 'movie-view')
#83
def vidoza(url):
    c = 0
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser")
    for a in soup.findAll(class_="ladoA"):
        icon = a.img['src']
        name1 = a.img.get('alt').encode('utf-8')
        if '/ ' in name1:
            name1 = name1.split('/ ')[1]
    for u in soup.findAll(style="font-size: 14pt;"):
        for l in u.findAll('a'):
            url = l['href']
            if 'vidoza' in url:
                name =  '  [B][COLOR yellow]' +addon.Lang(32045).encode('utf-8')+ '[/COLOR][/B]'
                c = c + 1
                url = url.replace('http://adf.ly/13975431/','')
                url = url.replace('http://adfly/13975431/','')
                url = url.replace('http://adf.ly/17390189/','')
                openn.addDir('[B][COLOR white]%s[/COLOR][/B]' '%s' '[B][COLOR white]%s[/COLOR][/B]' %(name1,name,c),url,200,icon,addon.art,'')  

                            
def vidto(url):
    c = 0
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser")
    for a in soup.findAll(class_="ladoA"):
        icon = a.img['src']
        name1 = a.img.get('alt').encode('utf-8')
        if '/ ' in name1:
            name1 = name1.split('/ ')[1]        
    for u in soup.findAll(style="font-size: 14pt;"):
        for l in u.findAll('a'):
            url = l['href']
            if 'vidto' in url:
                name =  '  [B][COLOR yellow]' +addon.Lang(32045).encode('utf-8')+ '[/COLOR][/B]'
                c = c + 1
                url = url.replace('http://adf.ly/13975431/','')
                url = url.replace('http://adfly/13975431/','')
                url = url.replace('http://adf.ly/17390189/','')
                openn.addDir('[B][COLOR white]%s[/COLOR][/B]' '%s' '[B][COLOR white]%s[/COLOR][/B]' %(name1,name,c),url,200,icon,addon.art,'')
              

def openload(url):
    c = 0
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser")
    for a in soup.findAll(class_="ladoA"):
        icon = a.img['src']
        name1 = a.img.get('alt').encode('utf-8')
        if '/ ' in name1:
            name1 = name1.split('/ ')[1]        
    for u in soup.findAll(style="font-size: 14pt;"):
        for l in u.findAll('a'):
            url = l['href']
            if 'openload' in url:
                name =  '  [B][COLOR yellow]' +addon.Lang(32045).encode('utf-8')+ '[/COLOR][/B]'
                c = c + 1
                url = url.replace('http://adf.ly/13975431/','')
                url = url.replace('http://adfly/13975431/','')
                url = url.replace('http://adf.ly/17390189/','')
                openn.addDir('[B][COLOR white]%s[/COLOR][/B]' '%s' '[B][COLOR white]%s[/COLOR][/B]' %(name1,name,c),url,200,icon,addon.art,'')


def Search6():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = 'http://tainies4k.online/?s=' + search
            get_contS(url)
    else: return

def xrysoiseries(url):
    p = openn.Open_Url(url)
    m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)" height="125px" width="119px" title=".+?">',re.DOTALL).findall(p)
    for url,icon,name in m:
        name = name.split('&#038;')[0]
        name = name.split('&#8217;')[0]
        name = name.split('&#8211;')[0]
        icon = icon.replace('-119x125','')
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,312,icon,addon.art,'')
    try:
        m=re.compile('class="nextpostslink" rel="next" href="(.+?)">»</a>').findall(p)[0]
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,416,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass
    setView.setView('movies', 'movie-view')


def get_hdvid(url):
        c = 'Επεισόδιο..'
        p = openn.Open_Url(url)
        m=re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(p)     
        for url,name in m:
            if 'streamcloud' in url or 'vidto' in url or 'streamin' in url or 'exashare.com' in url or 'hdvid.tv' in url or 'vidzi.tv' in url or 'openload' in url:     
                c = 'Επεισόδιο...'
                openn.addDir('[B][COLOR gold] %s[/COLOR][/B][B][COLOR blue]%s[/COLOR][/B]'%(c,name),url,200,addon.icon,addon.art,'')    
                

def Search9():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://xrysoi.online/?s=' + search
                xrysoiseries(url)                                  


def peiratesseries(url):
        p = openn.Open_Url(url)
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)" height="125px" width="119px" title=".+?">',re.DOTALL).findall(p)
        for url,icon,name in m:
            name = name.split('&#038;')[0]
            name = name.split('&#8217;')[0]
            name = name.split('&#8211;')[0]
            icon = icon.replace('-119x125','')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,56,icon,addon.art,'')
        try:
            m=re.compile('class="nextpostslink" rel="next" href="(.+?)">»</a>').findall(p)[0]
            openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,55,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
        except:pass
        setView.setView('movies', 'movie-view')     
        
def get_peiratesseries(url):
        c = 'Επεισόδιο..'
        p = openn.Open_Url(url)
        m=re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(p)     
        for url,name in m:
            if 'streamcloud' in url or 'vidto' in url or 'streamin' in url or 'exashare.com' in url or 'hdvid.tv' in url or 'vidzi.tv' in url or 'openload' in url:     
                c = 'Επεισόδιο...'
                openn.addDir('[B][COLOR gold] %s[/COLOR][/B][B][COLOR blue]%s[/COLOR][/B]'%(c,name),url,200,addon.icon,addon.art,'')          


def Search11():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://oipeirates.online/?s=' + search
                peiratesseries(url) 