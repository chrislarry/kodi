# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time

from resources.lib.clean import addon
from resources.lib.clean import openn
from resources.lib.modules import plugintools




def hermesM(url):
    addLink('LiveGreekTV','https://raw.githubusercontent.com/HermesGR/LiveGreekTV/master/README.m3u','https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    addLink('WorldIptv','https://raw.githubusercontent.com/HermesGR/WorldIptv/master/README.m3u','https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    addLink('Greek Kids','https://raw.githubusercontent.com/HermesGR/Hermes-Kids-Videos/master/kids.m3u','https://static-s.aa-cdn.net/img/gp/20600001285232/Su-mF-6fkMDYu_8jbxPBltkAYqxuVO-QCpnzdqa1QNizoMbdtNOQS48ykotV3U1uh9E=w300')
    addLink('Greek History Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Istorika/master/Documentaries%20Istorika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addLink('Greek Religious Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Thriskeutika/master/Documentaries%20Thriskeutika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addLink('Greek Scientific Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Epistimonika/master/Documentaries%20Epistimonika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addLink('Greek Various Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Diafora/master/Documentaries%20Diafora.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    addLink('Karaoke','https://raw.githubusercontent.com/HermesGR/Karaoke/master/README.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    addLink('Greek Concerts','https://raw.githubusercontent.com/HermesGR/Hermes-Synaulies/master/Greek%20Synaulies.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    addLink('Greek Music Collections','https://raw.githubusercontent.com/HermesGR/Greek-Music-Collection/master/Greek%20Music%20Collection.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    addLink('Greek Funny Moments','https://raw.githubusercontent.com/HermesGR/Hermes-Fun/master/Greek%20Fun.m3u','http://cdn.warer.com/media/hidden_emoticon_yahoo-logo.png')
    addLink('Greek Theater','https://raw.githubusercontent.com/HermesGR/Hermes-Epithewrisi/master/Greek%20Theater.m3u','https://pbs.twimg.com/profile_images/848319608062828544/A50dsvWj_400x400.jpg')
    addLink('Greek Sports Events - Full Matches','https://raw.githubusercontent.com/HermesGR/Hermes-Best-Greek-Moments/master/GreekMoments.m3u','https://is1-ssl.mzstatic.com/image/thumb/Purple60/v4/92/ae/e4/92aee442-6b32-0850-4f47-8c4f01792b29/source/256x256bb.jpg')
    addLink('Donation','https://raw.githubusercontent.com/HermesGR/Donation/master/README.m3u','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBUHgNiWy--QLFIBfjiQ4FBuI1ZirVYuUVvZazlOPwi36_TiJdOQ')


#url = 'https://raw.githubusercontent.com/HermesGR/Hermes-Kids-Videos/master/kids.m3u'
def hermes(url):
    p = openn.Open_Url(url)
    m = re.compile('#.+,(.+?)\n(.+?)\n').findall(p)
    for name,url in m:
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,250,addon.icon,addon.art,'')
        #openn.addLink('[B][COLOR white]%s[/COLOR][/B]'%name,url,'',addon.icon,addon.art,'')



        # if '.ts' in url:
        #     stype = 'TSDOWNLOADER'
        # elif '.m3u' in url:





    # addLink('LiveGreekTV','https://raw.githubusercontent.com/HermesGR/LiveGreekTV/master/README.m3u','https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    # addLink('WorldIptv','https://raw.githubusercontent.com/HermesGR/WorldIptv/master/README.m3u','https://is3-ssl.mzstatic.com/image/thumb/Purple127/v4/e0/7e/fe/e07efe97-54b8-5004-eb75-fbe7905741ce/source/256x256bb.jpg')
    # addLink('Greek Kids','https://raw.githubusercontent.com/HermesGR/Hermes-Kids-Videos/master/kids.m3u','https://static-s.aa-cdn.net/img/gp/20600001285232/Su-mF-6fkMDYu_8jbxPBltkAYqxuVO-QCpnzdqa1QNizoMbdtNOQS48ykotV3U1uh9E=w300')
    # addLink('Greek History Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Istorika/master/Documentaries%20Istorika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Greek Religious Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Thriskeutika/master/Documentaries%20Thriskeutika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Greek Scientific Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Epistimonika/master/Documentaries%20Epistimonika.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Greek Various Documentaries','https://raw.githubusercontent.com/HermesGR/Hermes-Documentaries-Diafora/master/Documentaries%20Diafora.m3u','https://www.shareicon.net/download/2017/06/22/887549_video.ico')
    # addLink('Karaoke','https://raw.githubusercontent.com/HermesGR/Karaoke/master/README.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    # addLink('Greek Concerts','https://raw.githubusercontent.com/HermesGR/Hermes-Synaulies/master/Greek%20Synaulies.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    # addLink('Greek Music Collections','https://raw.githubusercontent.com/HermesGR/Greek-Music-Collection/master/Greek%20Music%20Collection.m3u','http://www.iconarchive.com/download/i60740/double-j-design/origami-colored-pencil/yellow-music.ico')
    # addLink('Greek Funny Moments','https://raw.githubusercontent.com/HermesGR/Hermes-Fun/master/Greek%20Fun.m3u','http://cdn.warer.com/media/hidden_emoticon_yahoo-logo.png')
    # addLink('Greek Theater','https://raw.githubusercontent.com/HermesGR/Hermes-Epithewrisi/master/Greek%20Theater.m3u','https://pbs.twimg.com/profile_images/848319608062828544/A50dsvWj_400x400.jpg')
    # addLink('Greek Sports Events - Full Matches','https://raw.githubusercontent.com/HermesGR/Hermes-Best-Greek-Moments/master/GreekMoments.m3u','https://is1-ssl.mzstatic.com/image/thumb/Purple60/v4/92/ae/e4/92aee442-6b32-0850-4f47-8c4f01792b29/source/256x256bb.jpg')
    # addLink('Donation','https://raw.githubusercontent.com/HermesGR/Donation/master/README.m3u','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBUHgNiWy--QLFIBfjiQ4FBuI1ZirVYuUVvZazlOPwi36_TiJdOQ')

# def function(url):
#     p = openn.Open_Url('https://raw.githubusercontent.com/HermesGR/LiveGreekTV/master/README.m3u')
#     m = re.compile('href="(.+?)"').findall(p)
#     for name,url in m:
#         addLink('[B][COLOR white]%s[/COLOR][/B]'%name,url,'',icon,'','')


#EXTINF:-1,.+?(.+?)\n(.+?)\n
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok   
