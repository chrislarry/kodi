# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time

from resources.lib.clean import addon
from resources.lib.modules import plugintools

spor=[
	("[B][COLOR white]AlfaSports WebTV[/COLOR][/B]", "channel/UCdPYqDltOMfPc4yoGCoSvFA", 'https://yt3.ggpht.com/-npQA_lo1UXs/AAAAAAAAAAI/AAAAAAAAAAA/arPlNSjb-zA/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]Sigmalive Sports[/COLOR][/B]", "channel/UCsGWm9Hg-5_Q9KGhAChEvGw", 'https://yt3.ggpht.com/-UJOwsjAdN1M/AAAAAAAAAAI/AAAAAAAAAAA/745faJmeLhQ/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]Cytavision Sports[/COLOR][/B]", "channel/UCymdjC8B1J5EBIWkBx2Locg", 'https://yt3.ggpht.com/-BvhiDh4OfhY/AAAAAAAAAAI/AAAAAAAAAAA/unC2QkPJpgo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]FutsAEL Web Tv[/COLOR][/B]", "channel/UCwwhDdBKRFN5bg7AkQVz7pA", 'https://yt3.ggpht.com/-y1wiAYQTlCU/AAAAAAAAAAI/AAAAAAAAAAA/unjaSR2qgSA/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),	
	("[B][COLOR white]Cyprus Basketball[/COLOR][/B]", "channel/UCaOif2TWAJoUX2b-krlW4Jg", 'https://yt3.ggpht.com/-aYjN28G2KvY/AAAAAAAAAAI/AAAAAAAAAAA/aMoogS8CSXU/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]APOEL FC[/COLOR][/B]", "channel/UCN_ITP8cJ0zcJOylc0YMvHg", 'https://yt3.ggpht.com/-iF2dQEOcgIY/AAAAAAAAAAI/AAAAAAAAAAA/SY96nCGwZ3w/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]AC Omonia[/COLOR][/B]", "channel/UC-WCyqDVbvEe8ZPE3Z1cXLg", 'https://yt3.ggpht.com/-RtE60-PdN3o/AAAAAAAAAAI/AAAAAAAAAAA/Tu4sciN68XU/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]APOLLON FC[/COLOR][/B]", "channel/UCU1e89ynCdCEF3i-mF4XP0A", 'https://yt3.ggpht.com/-68knMCn7PPA/AAAAAAAAAAI/AAAAAAAAAAA/88OUguU0XJo/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art)          
]

def spor1(params):
    for name, id, icon, fanart in spor:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
#####################################################################################
news=[
	("[B][COLOR white]AlphaNews[/COLOR][/B]", "channel/UCqaeodulp1p6snVJ5ApI6zA", 'https://yt3.ggpht.com/-fVbEpx7J3UA/AAAAAAAAAAI/AAAAAAAAAAA/MJgqSG-AQig/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]Capital TV[/COLOR][/B]", "channel/UCR8LwVKTLGEXt4ZAErpCMrg/playlists", 'https://yt3.ggpht.com/-TkzJFBxOpFM/AAAAAAAAAAI/AAAAAAAAAAA/A5ypOEZj3DI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]InBusinessNews[/COLOR][/B]", "channel/UCgv8ZTCHB2n4m8DPTvY3q-g", 'https://yt3.ggpht.com/-Wq4TzbtqVY8/AAAAAAAAAAI/AAAAAAAAAAA/iFpXSCxoUjI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]NewsitCy[/COLOR][/B]", "channel/UCwv1DjYj1sr7lys9aeJy-aQ", 'https://yt3.ggpht.com/-mvanwpX-tac/AAAAAAAAAAI/AAAAAAAAAAA/4OHCa0u6BtI/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]PafosNet[/COLOR][/B]", "channel/UCfy4zw4AZzd6yDK0rRekLMw", 'https://yt3.ggpht.com/-9Z5II1N3ReQ/AAAAAAAAAAI/AAAAAAAAAAA/St5vwiz8Sxs/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]Politis News[/COLOR][/B]", "channel/UCzP5oUhHmASfZKmQyT7mpaA", 'https://yt3.ggpht.com/-Rj7Tv45SL4A/AAAAAAAAAAI/AAAAAAAAAAA/YQDy_Y4doBc/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),
	("[B][COLOR white]Thema Online[/COLOR][/B]", "channel/UCw7I5zP0Ozl4t4ao-LhecuA", 'https://yt3.ggpht.com/-rGif3TLmVVU/AAAAAAAAAAI/AAAAAAAAAAA/qCCvg51TThM/s288-mo-c-c0xffffffff-rj-k-no/photo.jpg',addon.art),	
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art),
	# ("[B][COLOR white][/COLOR][/B]", "", '',addon.art)    
]

def news1(params):
    for name, id, icon, fanart in news:
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,fanart=addon.art,folder=True )
###############################################################################
def run():
    plugintools.log("youtubeAddon.run")
    

    params = plugintools.get_params()
    
    if params.get("action") is None:
        you_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def you_list(params):
    plugintools.log("youtubeAddon.you_list "+repr(params)) 
####################################################################################           
def radiocy():
    addLink('Mix FM 102.3','http://eco.onestreaming.com:8127/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/371.jpg')
    addLink('1Sports','http://eco.onestreaming.com:8486/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1416.jpg')
    addLink('Star Fm 93.7','http://eco.onestreaming.com:8538/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1529.jpg')
    addLink('Kanali 6 106 FM','http://live3.istoikona.net:8372/stream/2/','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1587.jpg')
    addLink('Rock Fm 106.7','http://live3.istoikona.net:8456/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1830.jpg')
    addLink('Choice FM 104.3','http://eco.onestreaming.com:8364/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1554.jpg')
    addLink('Choice FM 107.4','http://eco.onestreaming.com:8364/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1555.jpg')
    addLink('Melodia entexno','http://eco.onestreaming.com:8031/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1556.jpg')
    addLink('Radio O Logos 101.1','http://r1.cloudskep.com/radio/logos101/icecast.audio','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1929.jpg')
    addLink('Radio Proto 99.3','http://eco.onestreaming.com:8191/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1521.jpg')
    addLink('107.6 fm','http://live3.istoikona.net:8199/;','http://www.24htv.eu/DesktopModules/PropertyAgent/ImageHandler.ashx?width=289&height=240&HomeDirectory=%2fPortals%2f45%2f%2fPropertyAgent%2f4801%2fImages&fileName=1522.jpg&portalid=45&i=1522&Q=True')
    addLink('Astra Radio','http://radio.dialogos.com.cy:8000/stream','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1523.jpg')
    addLink('Radio 5','http://live3.istoikona.net:8436/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1531.jpg')
    addLink('Super Fm 104.8','http://live3.istoikona.net:8175/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1525.jpg')
    addLink('Sfera 96.8','http://phileradio.com:8193/sfera','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1526.jpg')
    addLink('Zenith fm 96.4','http://live3.istoikona.net:8023/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1528.jpg')
    addLink('Rock Fm 98.5','http://live3.istoikona.net:8278/;','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1532.jpg')
    addLink('Sport FM Κύπρου','http://sportfm-cyprus.live24.gr/sportfm-cyprus','http://www.24htv.eu/Portals/45/PropertyAgent/4801/Images/1520.jpg')
    # addLink('','','')    
    # addLink('','','')
    # addLink('','','')    

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok	





