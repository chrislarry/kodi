# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import urlresolver
import requests
import pyxbmct

from bs4 import BeautifulSoup
from resources.lib.clean import clean
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import addon

def Movie_menu():
    openn.addDir('[B][COLOR white]' +addon.Lang(32022).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/astinomiki/',13,'http://i.imgur.com/X7HlC7y.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32023).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/biographia/',13,'http://i.imgur.com/oISI2XW.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32024).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/western/',13,'http://i.imgur.com/HjAkg1K.png',addon.art,'')        
    openn.addDir('[B][COLOR white]' +addon.Lang(32025).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/drasi/',13,'http://i.imgur.com/0hiqxAv.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32026).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/drama/',13,'http://i.imgur.com/0eOMDmx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]' +addon.Lang(32027).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/egklima/',13,'http://i.imgur.com/X7HlC7y.png',addon.art,'')            
    openn.addDir('[B][COLOR white]' +addon.Lang(32028).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/ep-fantasias/',13,'http://i.imgur.com/fdpacDi.png',addon.art,'')           
    openn.addDir('[B][COLOR white]' +addon.Lang(32029).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/thriller/',13,'http://i.imgur.com/ngYlXLg.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32030).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/komodia/',13,'http://i.imgur.com/EdBxqOi.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32031).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/mistiriou/',13,'http://i.imgur.com/kIueNtO.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32032).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/oikogeneiaki/',13,'http://i.imgur.com/mcZvo7R.png',addon.art,'')      
    openn.addDir('[B][COLOR white]' +addon.Lang(32033).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/polemiki/',13,'http://i.imgur.com/OvpHFdT.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32034).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/peripeteia/',13,'http://i.imgur.com/4lLOa0L.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32035).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/romantiki/',13,'http://i.imgur.com/KtM7LDx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]' +addon.Lang(32036).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/tromou/',13,'http://i.imgur.com/BLwEyfJ.png',addon.art,'')               
    openn.addDir('[B][COLOR white]' +addon.Lang(32037).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/category/fantasias/',13,'http://i.imgur.com/jTyZIAW.png',addon.art,'')                
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ '[/COLOR][/B]','http://tainies4k.online/',96,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'')
##################################################################################################################################
def new():
    openn.addDir('[B][COLOR white]' +addon.Lang(32038).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/listByLocation?location=2017&sort=mostRecent',26,'http://i.imgur.com/V68jVUi.png',addon.art,'')    
    openn.addDir('[B][COLOR white]2017 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2017&sort=mostPopular',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'')     
    openn.addDir('[B][COLOR white]2016 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2016&sort=mostPopular',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]2015 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2015&sort=mostPopular',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]2014 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2014&sort=mostPopular&xg_source=shorten_status',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]2013 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2013&sort=mostPopular&xg_source=shorten_status',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]2012 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2012&sort=mostPopular&xg_source=shorten_status',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]2011 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2011&sort=mostPopular&xg_source=shorten_status',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]2010 ([B][COLOR green]TOP[/COLOR][/B])','http://gamatotv.me/groups/group/listByLocation?location=2010&sort=mostPopular&xg_source=shorten_status',26,'https://i.imgur.com/Mveo2KC.png',addon.art,'') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32039).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Sport-%CE%86%CE%B8%CE%BB%CE%B7%CE%BC%CE%B1&page=',26,'http://i.imgur.com/f6WzuWx.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32023).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Biography-%CE%92%CE%B9%CE%BF%CE%B3%CF%81%CE%B1%CF%86%CE%AF%CE%B1&page=',26,'http://i.imgur.com/oISI2XW.png',addon.art,'')     
    openn.addDir('[B][COLOR white]' +addon.Lang(32024).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Western-%CE%93%CE%BF%CF%85%CE%AD%CF%83%CF%84%CE%B5%CF%81%CE%BD&page=',26,'http://i.imgur.com/HjAkg1K.png',addon.art,'')     
    openn.addDir('[B][COLOR white]' +addon.Lang(32025).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Action-%CE%94%CF%81%CE%AC%CF%83%CE%B7',26,'http://i.imgur.com/0hiqxAv.png',addon.art,'') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32026).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Drama-%CE%94%CF%81%CE%AC%CE%BC%CE%B1',26,'http://i.imgur.com/0eOMDmx.png',addon.art,'') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32028).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Sci-Fi',26,'http://i.imgur.com/fdpacDi.png',addon.art,'')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32027).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Crime-%CE%88%CE%B3%CE%BA%CE%BB%CE%B7%CE%BC%CE%B1',26,'http://i.imgur.com/X7HlC7y.png',addon.art,'') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32029).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Thriller-%CE%98%CF%81%CE%AF%CE%BB%CE%B5%CF%81',26,'http://i.imgur.com/ngYlXLg.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32040).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=History-%CE%99%CF%83%CF%84%CE%BF%CF%81%CE%AF%CE%B1',26,'http://i.imgur.com/YxpsMCi.png',addon.art,'')    
    openn.addDir('[B][COLOR white]' +addon.Lang(32030).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Comedy-%CE%9A%CF%89%CE%BC%CF%89%CE%B4%CE%AF%CE%B1',26,'http://i.imgur.com/EdBxqOi.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32031).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Mystery-%CE%9C%CF%85%CF%83%CF%84%CE%AE%CF%81%CE%B9%CE%BF',26,'http://i.imgur.com/kIueNtO.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32032).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Family-%CE%9F%CE%B9%CE%BA%CE%BF%CE%B3%CE%AD%CE%BD%CE%B5%CE%B9%CE%B1',26,'http://i.imgur.com/mcZvo7R.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32034).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Adventure-%CE%A0%CE%B5%CF%81%CE%B9%CF%80%CE%AD%CF%84%CE%B5%CE%B9%CE%B1',26,'http://i.imgur.com/4lLOa0L.png',addon.art,'') 
    openn.addDir('[B][COLOR white]' +addon.Lang(32033).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=War-%CE%A0%CF%8C%CE%BB%CE%B5%CE%BC%CE%BF%CF%82',26,'http://i.imgur.com/OvpHFdT.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32035).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Romance-%CE%A1%CE%BF%CE%BC%CE%AC%CE%BD%CF%84%CE%B6%CE%BF',26,'http://i.imgur.com/KtM7LDx.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32036).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Horror-%CE%A4%CF%81%CF%8C%CE%BC%CE%BF%CF%85',26,'http://i.imgur.com/BLwEyfJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32037).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Fantasy-%CE%A6%CE%B1%CE%BD%CF%84%CE%B1%CF%83%CE%AF%CE%B1',26,'http://i.imgur.com/jTyZIAW.png',addon.art,'')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ '[/COLOR][/B]','http://gamatotv.me/',97,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
##############################################################################################################################

def get_xronia():
    p = openn.Open_Url('http://tainies4k.online/')
    r = re.compile('<ul class="scrolling" style="max-height: 300px;">(.+?)</ul>',re.DOTALL).findall(p)
    r2 = re.compile('<li><a href="(.+?)" data-wpel-link="internal">(.+?)</a></li>',re.DOTALL).findall(str(r))[:50]
    for url,name in r2:
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,13,'https://i.imgur.com/Mveo2KC.png',addon.art,'')

def get_content(url):
        p = openn.Open_Url(url)
        m=re.compile('<div id=".+?" class="item">.+?<a href="(.+?)" data-wpel-link="internal">.+?<div class="image">.+?<img src="(.+?)" alt="(.+?)" width="100%" height="100%" />.+?<span class="ttx">(.+?)<div class="degradado">.+?class="dato">(.+?)<b>(.+?)</b>.+?class="year">(.+?)</span>.+?<span class="calidad2">(.+?)</span>',re.DOTALL).findall(p)
        for url,icon,name,desc,name2,rat,year,rat2 in m:
            year = '[B][COLOR white]([/COLOR]' + year + '[B][COLOR white])[/COLOR]'
            name = clean.Clean(name)
            desc = clean.Clean(desc)
            desc = desc.replace('#38;','')
            if '/ ' in name:
                name = name.split('/ ')[1]
                if ':' in name:
                    name = name.split(':')[0]  
            if 'Ο Βιασμός μιας Μοναχής' not in name:
                    if 'Vampyros Lesbos' not in name:
                        if 'Προσεχώς' not in rat2:
                            t = '***Περίληψη***'
                            openn.addDir('[B][COLOR white]%s[/COLOR][/B]  [B][COLOR green]%s[/COLOR][/B] [B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B]'
                            %(name,year,name2,rat),url,14,icon,addon.art,'[B][COLOR green]\n%s[/COLOR][/B]''%s' %(t,desc))
        try:
            r=re.compile('<div class="pag_b"><a href="(.+?)" data-wpel-link="internal">Επόμενη</a></div>').findall(p)[0]
            openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',r,13,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
        except:pass            
        setView.setView('movies', 'movie-view') 

def GETSOURCES4k(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser")
    for a in soup.findAll(class_="s_left"):
        for i in a.findAll(class_="fix"):
            icon = i.img['src']
            name = i.img.get('alt').encode('utf-8')
            if '/ ' in name:
                name = name.split('/ ')[1]
                if ':' in name:
                    name = name.split(':')[0]
            for d in a.findAll(itemprop="description"):
                desc = d.p.text.encode('utf-8')
                for l in a.findAll('li', class_="elemento"):
                    for p in l.findAll('a'):
                        url = p['href']
                        url = url.replace('http://adf.ly/17390189/', '').replace('http://adf.ly/13975431/', '').replace(
                            'http://adf.ly/9324147/', '').replace('http://adf.ly/18055401/', '')
                        for m in l.findAll('img'):
                            name2 = m.get('alt').encode('utf-8')
                            name2 = name2.split('.')[0]
                            if 'flashx' not in name2:
                                if 'easybytez' not in name2:   
                                    for m2 in l.findAll(class_="c"):
                                        name3 = m2.text.encode('utf-8')
                                        name3 = name3.replace('ικοί','.')
                                        for t in a.findAll(itemprop="duration"):
                                            time = t.text.encode('utf-8')
                                            time = time.replace('min','Λεπτά')
                                            w = '***Περίληψη***'
                                            openn.addDir('[B][COLOR white]%s[/COLOR][/B]  [B][COLOR green]%s[/COLOR][/B] [B][COLOR white]%s[/COLOR][/B][B][COLOR yellow] %s[/COLOR][/B]'
                                            %(name,name2,name3,time),url,200,icon,addon.art,'[B][COLOR green]%s[/COLOR][/B]''\n''%s' %(w,desc))
    class MyWindow(pyxbmct.AddonDialogWindow):

        def __init__(self, title=''):
            super(MyWindow, self).__init__(title)
            self.setGeometry(700, 500, 5, 2)
            self.set_controls()
            self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

        def set_controls(self):
            image = pyxbmct.Image(icon)
            self.placeControl(image, 0, 0, 4, 1)
            self.textbox = pyxbmct.TextBox()
            self.placeControl(self.textbox, 0, 1, 4, 1)
            self.textbox.setText('[B][COLOR green]%s[/COLOR][/B]''\n''%s' %(w,desc))
            self.textbox.autoScroll(4000, 4000, 5000)
            self.fade_label = pyxbmct.FadeLabel()
            self.placeControl(self.fade_label, 4, 1)
            self.fade_label.addLabel('[B][COLOR yellow]%s[/COLOR][/B]' '\n' '[B][COLOR yellow]%s[/COLOR][/B]' %(name3,time))
            self.close_button = pyxbmct.Button('[B][COLOR white]Κλείσε για παρόχους[/COLOR][/B]''\n''(Return σε Android)')
            self.placeControl(self.close_button, 4, 0)
            self.connect(self.close_button, self.close)

        def setAnimation(self, control):
            control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])


    window = MyWindow('[B][COLOR yellow]%s[/COLOR][/B]' %(name))
    window.doModal()
    del window      
 

def Search1():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'http://tainies4k.online/?s=' + search
                get_content(url)
        else: return

def katigoria(url):
        p = openn.Open_Url(url)
        m=re.compile('<img src="(.+?)" width="82" height="82" alt="(.+?)".+?<a href="(.+?)">.+?</a>',re.DOTALL).findall(p)
        for icon,name,url in m:
            name = name.split('/ ')[0]
            name = name.split('&Mu;')[0].split('&Eta;')[0].split('&pi;')[0]
            name = clean.Clean(name)
            icon = icon.split('?')[0]
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,27,icon,addon.art,'')
        try:
            m=re.compile('href="(.+?)">Επόμενο ›</a></li>').findall(p)[0]
            m = m.replace('amp;','')
            openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,26,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
        except:pass

def susres(url):
        p = openn.Open_Url(url)
        m1 = re.compile('<meta name="description" content="(.+?)" />',re.DOTALL).findall(p)
        for desc in m1:
            desc = desc.replace('&amp;','').replace('nbsp;','')
            m2 = re.compile('<link rel="image_src" href="(.+?)" />.+?<h1>(.+?)</h1>',re.DOTALL).findall(p)
        for icon,name2 in m2:
            m3 = re.compile('<a href="(.+?)"').findall(p)
        for url in m3:
            if not 'gamato' in url:
                if 'openload' in url or 'vidoza' in url or 'vidto' in url or 'vidzi' in url or 'vidup' in url or 'streamcloud' in url or 'streamin' in url or 'streamango' in url or 'estream' in url:
                    name2 = name2.split('/ ')[0].split('&Mu;')[0].split('&Eta;')[0].split('&pi;')[0]
                    name2 = name2.replace('&#039;','').replace('&frac12;','').replace('&rsquo;','').replace('&ocirc;','').replace('amp;','')
                    name = url
                    name = url.replace('http://','').replace('https://','')
                    name = name.split('.')[0]
                    openn.addDir('[B][COLOR white]%s[/COLOR][/B]  [B][COLOR green]%s[/COLOR][/B]'%(name2,name),url,200,icon,'',desc)

def Search2():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'http://gamatotv.me/groups/group/search?q=' + search
                katigoria(url)
        else: return
######################################################################################################################################################################################################################################
def Movie_menu4():
    openn.addDir('[B][COLOR white]Βιογραφία[/COLOR][/B]','https://xrysoi.online/category/%CF%86%CE%B9%CE%BB%CE%BC%CE%BF%CE%B3%CF%81%CE%B1%CF%86%CE%AF%CE%B5%CF%82/',313,'http://i.imgur.com/oISI2XW.png',addon.art,'')
    openn.addDir('[B][COLOR white]Γουέστερν[/COLOR][/B]','https://xrysoi.online/category/western/',313,'http://i.imgur.com/HjAkg1K.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Δράμα[/COLOR][/B]','https://xrysoi.online/category/%CE%B4%CF%81%CE%AC%CE%BC%CE%B1/',313,'http://i.imgur.com/0eOMDmx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Έγκλημα[/COLOR][/B]','https://xrysoi.online/category/%CE%AD%CE%B3%CE%BA%CE%BB%CE%B7%CE%BC%CE%B1/',313,'http://i.imgur.com/X7HlC7y.png',addon.art,'')            
    openn.addDir('[B][COLOR white]Επ. Φαντασίας[/COLOR][/B]','https://xrysoi.online/category/%CE%B5%CF%80-%CF%86%CE%B1%CE%BD%CF%84%CE%B1%CF%83%CE%AF%CE%B1%CF%82/',313,'http://i.imgur.com/fdpacDi.png',addon.art,'')           
    openn.addDir('[B][COLOR white]Θρίλερ[/COLOR][/B]','https://xrysoi.online/category/%CE%B8%CF%81%CE%AF%CE%BB%CE%B5%CF%81/',313,'http://i.imgur.com/ngYlXLg.png',addon.art,'')
    openn.addDir('[B][COLOR white]Κωμωδία[/COLOR][/B]','https://xrysoi.online/category/%CE%BA%CF%89%CE%BC%CF%89%CE%B4%CE%AF%CE%B5%CF%82/',313,'http://i.imgur.com/EdBxqOi.png',addon.art,'')
    openn.addDir('[B][COLOR white]Μυστηρίου[/COLOR][/B]','https://xrysoi.online/category/%CE%BC%CF%85%CF%83%CF%84%CE%AE%CF%81%CE%B9%CE%BF/',313,'http://i.imgur.com/kIueNtO.png',addon.art,'')
    #openn.addDir('[B][COLOR white]Collection[/COLOR][/B]','https://xrysoi.online/category/collection/',313,'special://home/addons/resources/art/siloges.png',addon.art,'')      
    openn.addDir('[B][COLOR white]Πολεμική[/COLOR][/B]','https://xrysoi.online/category/%CF%80%CE%BF%CE%BB%CE%AD%CE%BC%CE%BF%CF%85/',313,'http://i.imgur.com/OvpHFdT.png',addon.art,'')
    openn.addDir('[B][COLOR white]Περιπέτεια[/COLOR][/B]','https://xrysoi.online/category/%CE%B4%CF%81%CE%AC%CF%83%CE%B7%CF%82/',313,'http://i.imgur.com/4lLOa0L.png',addon.art,'')
    openn.addDir('[B][COLOR white]Ρομαντική[/COLOR][/B]','https://xrysoi.online/category/%CF%81%CE%BF%CE%BC%CE%B1%CE%BD%CF%84%CE%B9%CE%BA%CE%AD%CF%82/',313,'http://i.imgur.com/KtM7LDx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Τρόμου[/COLOR][/B]','https://xrysoi.online/category/%CF%84%CF%81%CF%8C%CE%BC%CE%BF%CF%85/',313,'http://i.imgur.com/BLwEyfJ.png',addon.art,'')               
    openn.addDir('[B][COLOR white]Φαντασίας[/COLOR][/B]','https://xrysoi.online/category/%CF%86%CE%B1%CE%BD%CF%84%CE%B1%CF%83%CE%AF%CE%B1%CF%82/',313,'http://i.imgur.com/jTyZIAW.png',addon.art,'') 

def xrysoimovies(url):
        p = openn.Open_Url(url)
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)" height="125px" width="119px" title=".+?">',re.DOTALL).findall(p)
        for url,icon,name in m:
            name = name.split('&#038;')[0]
            name = name.split('&#8217;')[0]
            name = name.split('&#8211;')[0]
            icon = icon.replace('-119x125','')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,314,icon,addon.art,'')
        try:
            m=re.compile('class="nextpostslink" rel="next" href="(.+?)">»</a>').findall(p)[0]
            openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,313,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
        except:pass
        setView.setView('movies', 'movie-view')     
        
def get_xrysoimovies(url):
        p = openn.Open_Url(url)
        m = re.compile('href="(.+?)"').findall(p)
        for url in m:
            if 'streamcloud' in url or 'vidto' in url or 'streamin' in url or 'exashare.com' in url or 'hdvid' in url or 'vidzi.tv' in url or 'openload' in url:
                name = url                  
                name = name.split('.')[0]
                name = name.replace('http://','Πάροχος...')
                name = name.replace('https://','Πάροχος...')                
                openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,addon.icon,addon.art,'')                  


def get_hdvid(url):
        c = 'Επεισόδιο..'
        p = openn.Open_Url(url)
        m=re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(p)     
        for url,name in m:
            if 'streamcloud' in url or 'vidto' in url or 'streamin' in url or 'exashare.com' in url or 'hdvid.tv' in url or 'vidzi.tv' in url or 'openload' in url:     
                c = 'Επεισόδιο...'
                openn.addDir('[B][COLOR gold] %s[/COLOR][/B][B][COLOR blue]%s[/COLOR][/B]'%(c,name),url,200,addon.icon,addon.art,'') 

def Search8():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://xrysoi.online/?s=' + search
                xrysoimovies(url)   


###############################################################################################################################################
def Movie_menu3():
    openn.addDir('[B][COLOR white]Βιογραφία[/COLOR][/B]','https://oipeirates.online/tenies-online/filmography',9,'http://i.imgur.com/oISI2XW.png',addon.art,'')
    openn.addDir('[B][COLOR white]Γουέστερν[/COLOR][/B]','https://oipeirates.online/tenies-online/western',9,'http://i.imgur.com/HjAkg1K.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Δράση[/COLOR][/B]','https://oipeirates.online/tenies-online/drasis',9,'http://i.imgur.com/0hiqxAv.png',addon.art,'')
    openn.addDir('[B][COLOR white]Δράμα[/COLOR][/B]','https://oipeirates.online/tenies-online/drama',9,'http://i.imgur.com/0eOMDmx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Έγκλημα[/COLOR][/B]','https://oipeirates.online/tenies-online/egklima',9,'http://i.imgur.com/X7HlC7y.png',addon.art,'')            
    openn.addDir('[B][COLOR white]Επ. Φαντασίας[/COLOR][/B]','https://oipeirates.online/tenies-online/ep-fantasias',9,'http://i.imgur.com/fdpacDi.png',addon.art,'')           
    openn.addDir('[B][COLOR white]Θρίλερ[/COLOR][/B]','https://oipeirates.online/tenies-online/thriller',9,'http://i.imgur.com/ngYlXLg.png',addon.art,'')
    openn.addDir('[B][COLOR white]Κωμωδία[/COLOR][/B]','https://oipeirates.online/tenies-online/komodies',9,'http://i.imgur.com/EdBxqOi.png',addon.art,'')
    openn.addDir('[B][COLOR white]Μυστηρίου[/COLOR][/B]','https://oipeirates.online/tenies-online/mystery',9,'http://i.imgur.com/kIueNtO.png',addon.art,'')
    openn.addDir('[B][COLOR white]Οικογενειακή[/COLOR][/B]','http://tainies4k.online/category/oikogeneiaki/',9,'http://i.imgur.com/mcZvo7R.png',addon.art,'')      
    openn.addDir('[B][COLOR white]Πολεμική[/COLOR][/B]','https://oipeirates.online/tenies-online/war',9,'http://i.imgur.com/OvpHFdT.png',addon.art,'')
    openn.addDir('[B][COLOR white]Περιπέτεια[/COLOR][/B]','https://oipeirates.online/tenies-online/drasis',9,'http://i.imgur.com/4lLOa0L.png',addon.art,'')
    openn.addDir('[B][COLOR white]Ρομαντική[/COLOR][/B]','https://oipeirates.online/tenies-online/romantikes',9,'http://i.imgur.com/KtM7LDx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Τρόμου[/COLOR][/B]','https://oipeirates.online/tenies-online/tromou',9,'http://i.imgur.com/BLwEyfJ.png',addon.art,'')               
    openn.addDir('[B][COLOR white]Φαντασίας[/COLOR][/B]','https://oipeirates.online/tenies-online/fantasias',9,'http://i.imgur.com/jTyZIAW.png',addon.art,'')       
    
def peirates(url):
        p = openn.Open_Url(url)
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)" height="125px" width="119px" title=".+?">',re.DOTALL).findall(p)
        for url,icon,name in m:
            name = name.split('&#038;')[0]
            name = name.split('&#8217;')[0]
            name = name.split('&#8211;')[0]
            icon = icon.replace('-119x125','')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,8,icon,addon.art,'')
        try:
            m=re.compile('class="nextpostslink" rel="next" href="(.+?)">»</a>').findall(p)[0]
            openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,9,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
        except:pass
        setView.setView('movies', 'movie-view') 
 
def get_peirates(url):
        p = openn.Open_Url(url)
        m = re.compile('href="(.+?)"').findall(p)
        for url in m:
            if 'streamcloud' in url or 'vidto' in url or 'streamin' in url or 'exashare.com' in url or 'hdvid' in url or 'vidzi.tv' in url or 'openload' in url:
                name = url
                name = name.split('.')[0]
                name = name.replace('http://','')
                openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,icon,'','')

            
def Search7():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'https://oipeirates.online/?s=' + search
                peirates(url) 
#########################################################################################################################################################################
def Movie_menu2():
    openn.addDir('[B][COLOR white]Περιπέτεια[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Adventure-%CE%A0%CE%B5%CF%81%CE%B9%CF%80%CE%AD%CF%84%CE%B5%CE%B9%CE%B1',26,'',addon.art,'')    
    openn.addDir('[B][COLOR white]Βιογραφία[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Biography-%CE%92%CE%B9%CE%BF%CE%B3%CF%81%CE%B1%CF%86%CE%AF%CE%B1',26,'http://i.imgur.com/oISI2XW.png',addon.art,'')
    openn.addDir('[B][COLOR white]Γουέστερν[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Western-%CE%93%CE%BF%CF%85%CE%AD%CF%83%CF%84%CE%B5%CF%81%CE%BD',26,'http://i.imgur.com/HjAkg1K.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Δράση[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Action-%CE%94%CF%81%CE%AC%CF%83%CE%B7',26,'http://i.imgur.com/0hiqxAv.png',addon.art,'')
    openn.addDir('[B][COLOR white]Δράμα[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Drama-%CE%94%CF%81%CE%AC%CE%BC%CE%B1',26,'http://i.imgur.com/0eOMDmx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Έγκλημα[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Crime-%CE%88%CE%B3%CE%BA%CE%BB%CE%B7%CE%BC%CE%B1',26,'http://i.imgur.com/X7HlC7y.png',addon.art,'')            
    openn.addDir('[B][COLOR white]Επ. Φαντασίας[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Sci-Fi',26,'http://i.imgur.com/fdpacDi.png',addon.art,'')           
    openn.addDir('[B][COLOR white]Θρίλερ[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Thriller-%CE%98%CF%81%CE%AF%CE%BB%CE%B5%CF%81',26,'http://i.imgur.com/ngYlXLg.png',addon.art,'')
    openn.addDir('[B][COLOR white]Κωμωδία[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Comedy-%CE%9A%CF%89%CE%BC%CF%89%CE%B4%CE%AF%CE%B1',26,'http://i.imgur.com/EdBxqOi.png',addon.art,'')
    openn.addDir('[B][COLOR white]Μυστηρίου[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Mystery-%CE%9C%CF%85%CF%83%CF%84%CE%AE%CF%81%CE%B9%CE%BF',26,'http://i.imgur.com/kIueNtO.png',addon.art,'')
    openn.addDir('[B][COLOR white]Οικογενειακή[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Family-%CE%9F%CE%B9%CE%BA%CE%BF%CE%B3%CE%AD%CE%BD%CE%B5%CE%B9%CE%B1',26,'http://i.imgur.com/mcZvo7R.png',addon.art,'')      
    openn.addDir('[B][COLOR white]Πολεμική[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=War-%CE%A0%CF%8C%CE%BB%CE%B5%CE%BC%CE%BF%CF%82',26,'http://i.imgur.com/OvpHFdT.png',addon.art,'')
    openn.addDir('[B][COLOR white]Περιπέτεια[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Adventure-%CE%A0%CE%B5%CF%81%CE%B9%CF%80%CE%AD%CF%84%CE%B5%CE%B9%CE%B1',26,'http://i.imgur.com/4lLOa0L.png',addon.art,'')
    openn.addDir('[B][COLOR white]Ρομαντική[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Romance-%CE%A1%CE%BF%CE%BC%CE%AC%CE%BD%CF%84%CE%B6%CE%BF',26,'http://i.imgur.com/KtM7LDx.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Τρόμου[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Horror-%CE%A4%CF%81%CF%8C%CE%BC%CE%BF%CF%85',26,'http://i.imgur.com/BLwEyfJ.png',addon.art,'')               
    openn.addDir('[B][COLOR white]Φαντασίας[/COLOR][/B]','http://gamatotv.me/groups/group/search?q=Fantasy-%CE%A6%CE%B1%CE%BD%CF%84%CE%B1%CF%83%CE%AF%CE%B1',26,'http://i.imgur.com/jTyZIAW.png',addon.art,'')                  