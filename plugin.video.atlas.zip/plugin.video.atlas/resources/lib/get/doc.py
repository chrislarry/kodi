# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import requests

from bs4 import BeautifulSoup
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import clean
from resources.lib.clean import addon

def doc_menou():
    openn.addDir('[B][COLOR white]' +addon.Lang(32082).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/koinonika',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32083).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/istoria',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32084).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/mistirio',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32085).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/ntokimanter-me-zoa',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32086).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/ksena-ntokimanter',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32087).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/thriskeia',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32088).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/epistimi',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32089).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/periballon',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32090).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/oikonomia',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32091).encode('utf-8')+ '[/COLOR][/B]','http://ntokimanter.gr/videoscategory/politiki',60,'http://i.imgur.com/kkFddcJ.png',addon.art,'')

def doc_content(url):
    p = openn.Open_Url(url)
    r = re.compile('<div class="item-img">.+?<img width=".+?" height=".+?" src="(.+?)".+? alt="(.+?)" /></a>.+?<a href="(.+?)"><div class="img-hover">'
    ,re.DOTALL).findall(p)[:18]
    for icon,name,url in r:
        name = name.split('&#8211;')[0].replace('&#8217;','').replace('&#8216;','')
        p2= openn.Open_Url(url)
        m2 =re.compile('<div class="post-entry"><p>(.+?)</p>').findall(p2) 
        for desc in m2:
            desc = clean.Clean(desc)
            t = '***Περίληψη***'
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'
            %name,url,300,icon,addon.art,'[B][COLOR green]%s[/COLOR][/B]' '\n%s' %(t,desc))
    try:
        r=re.compile('class="next page-numbers" href="(.+?)">Next &rarr;</a></li>').findall(p)[0]
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',r,60,'http://i.imgur.com/rKSs0yq.png'
        ,addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass        
    setView.setView('movies', 'movie-view')