
# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import requests
import pyxbmct

from bs4 import BeautifulSoup
from resources.lib.clean import clean
from resources.lib.clean import setView
from resources.lib.clean import openn
from resources.lib.clean import addon

def newK():
    openn.addDir('[B][COLOR green]' +addon.Lang(32050).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/',33,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR green]' +addon.Lang(32051).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/tvshows-genre/%CE%BA%CE%B9%CE%BD%CE%BF%CF%8D%CE%BC%CE%B5%CE%BD%CE%B1-%CF%83%CF%87%CE%AD%CE%B4%CE%B9%CE%B1/',84,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32026).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%B4%CF%81%CE%AC%CE%BC%CE%B1/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32025).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%B4%CF%81%CE%AC%CF%83%CE%B7/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32028).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%B5%CF%80-%CF%86%CE%B1%CE%BD%CF%84%CE%B1%CF%83%CE%AF%CE%B1%CF%82/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32030).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%BA%CF%89%CE%BC%CF%89%CE%B4%CE%AF%CE%B1/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32052).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/quality/metaglotismeno/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')   
    openn.addDir('[B][COLOR white]' +addon.Lang(32053).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%BC%CE%B9%CE%BA%CF%81%CE%BF%CF%8D-%CE%BC%CE%AE%CE%BA%CE%BF%CF%85%CF%82/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32008).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%BC%CE%BF%CF%85%CF%83%CE%B9%CE%BA%CE%AE/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32032).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CE%BF%CE%B9%CE%BA%CE%BF%CE%B3%CE%B5%CE%BD%CE%B5%CE%B9%CE%B1%CE%BA%CE%AE/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32034).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CF%80%CE%B5%CF%81%CE%B9%CF%80%CE%AD%CF%84%CE%B5%CE%B9%CE%B1/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32037).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/%CF%86%CE%B1%CE%BD%CF%84%CE%B1%CF%83%CE%AF%CE%B1%CF%82/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR white]' +addon.Lang(32054).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/category/christmass/',29,'http://i.imgur.com/6bEuWDo.png',addon.art,'')
    openn.addDir('[B][COLOR red]' +addon.Lang(32009).encode('utf-8')+ '[/COLOR][/B]','http://paidikestainies.online/',98,'http://www.freeiconspng.com/uploads/search-icon-png-22.png',addon.art,'')

def KIDSANIME_menu():
    openn.addDir('[B][COLOR white]Παιδικά Μεταφρασμένα[/COLOR][/B]','https://oipeirates.online/tenies-online/kin-sxedia',9,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'')
    openn.addDir('[B][COLOR white]Παιδικά Υπότιτλοι[/COLOR][/B]','https://oipeirates.online/tenies-online/kin-sxedia-subs',9,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'')        
    openn.addDir('[B][COLOR white]Αnime Ταινίες[/COLOR][/B]','https://oipeirates.online/tenies-online/animemovies',9,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'')

def KIDSANIME():
    openn.addDir('[B][COLOR white]Παιδικά [/COLOR][COLOR green]peirates[/COLOR][/B]','https://oipeirates.online/',104,'https://oipeiratesonline.r.worldssl.net/wp-content/uploads/images/logo.png',addon.art,'Ξενες ταινιες με υποτιτλους.')    
    openn.addDir('[B][COLOR white]Παιδικά  [/COLOR][COLOR green]gamatotv[/COLOR][/B]','http://gamatotv.me/groups/group/',105,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'Ξενες ταινιες με υποτιτλους.')

def KIDSANIME_gamato():
    openn.addDir('[B][COLOR white]mostActive[/COLOR][/B]','http://gamatotv.me/groups/group/listByLocation?location=%CE%A0%CE%B1%CE%B9%CE%B4%CE%B9%CE%BA%CE%AC&sort=mostActive',26,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'')    
    openn.addDir('[B][COLOR white]latestActivity[/COLOR][/B]','http://gamatotv.me/groups/group/listByLocation?location=%CE%A0%CE%B1%CE%B9%CE%B4%CE%B9%CE%BA%CE%AC&sort=latestActivity',26,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'')
    openn.addDir('[B][COLOR white]mostRecent[/COLOR][/B]','http://gamatotv.me/groups/group/listByLocation?location=%CE%A0%CE%B1%CE%B9%CE%B4%CE%B9%CE%BA%CE%AC&sort=mostRecent',26,'https://techblog.gr/wp-content/uploads/2010/03/gamato.jpg',addon.art,'')

def katigoriaK(url):
    p = openn.Open_Url(url)
    r = re.compile('<div id=".+?" class="item">.+?<a href="(.+?)".+?<img src="(.+?)" alt="(.+?)" width="100%" height="100%" />.+?<span class="ttx">(.+?)<div class="degradado">.+?class="dato">(.+?)<b>(.+?)</b>.+?class="year">(.+?)</span>.+?<span class="calidad2">(.+?)</span>'
    ,re.DOTALL).findall(p)
    for url,icon,name,desc,name2,rat,year,rat2 in r:
        year = '[B][COLOR white]([/COLOR]' + year + '[B][COLOR white])[/COLOR]'
        name = clean.Clean(name)
        name2 = name2.replace('&#8217;','').replace('#038;','').replace('&#8211;','').replace('&#8220;','').replace('&#8221;','')
        if '/ ' in name:
            name = name.split('/ ')[1]
        if '\ ' in name:
            name = name.split('\ ')[1]              
        desc = clean.Clean(desc)
        desc = desc.split('Κατεβάστε')[0].split('όλο το αρχείο')[0].split('Δείτε')[0].split('Όλα τα επεισόδια')[0].split('Όλα ...')[0].replace('&#038;','')
        if 'Προσεχώς' not in rat2:
            t = '***Περίληψη***'
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]  [B][COLOR green]%s[/COLOR][/B] [B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B]'
            %(name,year,name2,rat),url,30,icon,addon.art,'[B][COLOR green]\n%s[/COLOR][/B]''%s' %(t,desc))
    try:
        m=re.compile('<div class="pag_b"><a href="(.+?)" data-wpel-link="internal">Next</a></div>').findall(p)[0]
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,29,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass        
    setView.setView('movies', 'movie-view')

def susresK(url):
    p = openn.Open_Url(url)
    m1 = re.compile('class="calidad2">(.+?)</span>.+?<img itemprop="image" src="(.+?)" alt="(.+?)" />.+?<i itemprop="duration">(.+?)</i>',re.DOTALL).findall(p)
    for title,icon,name2,time in m1:
        title = title.replace('λωτισμένο','').replace('Ελληνικοί','')
        name2 = name2.replace('&#8217;','').replace('&#038;','').replace('&#8211;','').replace('&#8221;','').replace('&#8220;','')
        name2 = name2 
        if '/ ' in name2:
			name2 = name2.split('/ ')[1]
        if '\ ' in name2:
            name2 = name2.split('\ ')[1]         
        time = time.replace('min','Λεπτά')
        m2 = re.compile('href="(.+?)"',re.DOTALL).findall(p)
        for url in m2:
            if 'openload' in url or 'vidto' in url or 'vidoza' in url or 'vidlox' in url or 'streamin' in url or 'vidabc' in url:    	
                url = url.replace('http://adf.ly/17390189/','')
                url = url.replace('http://adf.ly/13975431/','')
                url = url.replace('http://adf.ly/9324147/','')
                name = url
                name = name.replace('https://','').replace('http://','')
                name = name.split('.')[0]
                w = '***Περίληψη***'
                openn.addDir('[B][COLOR white]%s[/COLOR][/B] [B][COLOR green]%s[/COLOR][/B] %s' '[B][COLOR yellow] %s[/COLOR][/B]'
                %(name2,name,title,time),url,200,icon,addon.art,'')

def katigoriaK2(url):
    p = openn.Open_Url(url)
    r = re.compile('<div id=".+?" class="item">.+?<a href="(.+?)".+?<img src="(.+?)" alt="(.+?)" width="100%" height="100%" />.+?<span class="ttx">(.+?)<div class="degradado"></div>'
    ,re.DOTALL).findall(p)
    for url,icon,name,desc in r:
        desc = clean.Clean(desc)
        desc = desc.split('Κατεβάστε')[0].split('όλο το αρχείο')[0].split('Δείτε')[0].split('Όλα τα επεισόδια')[0].split('Όλα ...')[0].replace('&#038;','')
        name = name.replace('&#8217;','').replace('&#038;','').replace('&#8211;','').replace('&#8211;','')
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,32,icon,addon.art,desc)
    try:
        m=re.compile('<div class="pag_b"><a href="(.+?)" data-wpel-link="internal">Next</a></div>').findall(p)[0]
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,29,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass        
    setView.setView('movies', 'movie-view')

def susresK2(url):
    p = openn.Open_Url(url)
    m=re.compile('<a href="(.+?)" target="_blank".+?(.+?)</a>',re.DOTALL).findall(p)
    for url,name in m:
        name = clean.Clean(name)
        name = name.split('DTB')[0]
        name = name.split('avi')[0]
        name = name.split('AVI')[0]
        name = name.split('wmv')[0]
        name = name.split('mk')[0]
        name = name.split('WEB')[0]
        name = name.split('Sal70')[0]
        name = name.split('HDTV')[0]
        name = name.split('mp4')[0]
        url = url.replace('http://adf.ly/17390189/','')
        url = url.replace('http://adf.ly/13975431/','')
        if 'vidto'  in url:
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,addon.art,icon,'')

def katigoriaX(url):
    p = openn.Open_Url(url)
    r = re.compile('<li><a href="(.+?)" data-wpel-link="internal">(.+?)</a></li>',re.DOTALL).findall(p)[6:-6]
    for url,name in r:
    	if '1' or '2' in name:
    		if '1999-2010' not in url:
    			openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,29,'https://i.imgur.com/Mveo2KC.png',addon.art,'')

def collection(url):
    p = openn.Open_Url(url)
    m=re.compile('class="item">.+?<a href="(.+?)" data-wpel-link="internal">.+?class="image">.+?<img src="(.+?)" alt="(.+?)" width="100%" height="100%" />.+?<span class="ttx">(.+?)<div class="degradado">.+?class="dato">(.+?)<b>(.+?)</b>.+?<span class="year">(.+?)</span>'
    ,re.DOTALL).findall(p)
    for url,icon,name,desc,name2,rat,year in m:
        if '/ ' in name:
            name = name.split('/ ')[1]
        year = '[B][COLOR white]([/COLOR]'+ year +'[B][COLOR white])[/COLOR]'
        name = clean.Clean(name)
        desc = clean.Clean(desc)
        t = '***Περίληψη***'
        openn.addDir('[B][COLOR white]%s[/COLOR][/B]  [B][COLOR green]%s[/COLOR][/B] [B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B]'
            %(name,year,name2,rat),url,7,icon,addon.art,'[B][COLOR green]\n%s[/COLOR][/B]''%s' %(t,desc))
    try:
        m=re.compile('<div class="pag_b"><a href="(.+?)" data-wpel-link="internal">Next</a></div>').findall(p)[0]
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,84,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass        
    setView.setView('movies', 'movie-view')

def KIDS8(url):
    dialog = xbmcgui.Dialog()
    funcs = (collection1,collection4,collection2,collection3,collection)
    call = dialog.select('ATLAS:',
    ['[B][COLOR white]' +addon.Lang(32045).encode('utf-8')+ '[B][COLOR green]vidto[/COLOR][/B]',
    '[B][COLOR white]' +addon.Lang(32046).encode('utf-8')+ '[B][COLOR green]vidoza[/COLOR][/B]',
    '[B][COLOR white]' +addon.Lang(32046).encode('utf-8')+ '[B][COLOR green]vidlox[/COLOR][/B]',
    '[B][COLOR white]' +addon.Lang(32046).encode('utf-8')+ '[B][COLOR green]openload[/COLOR][/B]'])
    func = funcs[call]
    return func(url)

def collection1(url):
    c = 0
    c2 = addon.Lang(32055).encode('utf-8')
    p = openn.Open_Url(url)
    m1 = re.compile('<meta property="og:image" content="(.+?)" />.+?<div class="contenidotv">.+?<h2>(.+?)</h2>',re.DOTALL).findall(p)
    for icon,name in m1:
        name = clean.Clean(name) 
        if '/ ' in name:
            name = name.split('/ ')[1]
        m = re.compile('href="(.+?)"',re.DOTALL).findall(p)
    for url in m:
        if 'vidto' in url:
            c = c + 1
            c2 = addon.Lang(32055).encode('utf-8')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B] [B][COLOR green]%s[/COLOR][/B]'
            %(name,c2,c),url,200,icon,addon.art,'')

def collection2(url):
    c = 0
    c2 = addon.Lang(32055).encode('utf-8')
    p = openn.Open_Url(url)
    m1 = re.compile('<meta property="og:image" content="(.+?)" />.+?<div class="contenidotv">.+?<h2>(.+?)</h2>',re.DOTALL).findall(p)
    for icon,name in m1:
        name = clean.Clean(name) 
        if '/ ' in name:
            name = name.split('/ ')[1] 
        m = re.compile('href="(.+?)"',re.DOTALL).findall(p)
    for url in m:
        if 'vidlox' in url:
            c = c + 1
            c2 = addon.Lang(32055).encode('utf-8')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B] [B][COLOR green]%s[/COLOR][/B]'
            %(name,c2,c),url,200,icon,addon.art,'')

def collection3(url):
    c = 0
    c2 = addon.Lang(32055).encode('utf-8')
    p = openn.Open_Url(url)
    m1 = re.compile('<meta property="og:image" content="(.+?)" />.+?<div class="contenidotv">.+?<h2>(.+?)</h2>',re.DOTALL).findall(p)
    for icon,name in m1:
        name = clean.Clean(name) 
        if '/ ' in name:
            name = name.split('/ ')[1] 
        m = re.compile('href="(.+?)"',re.DOTALL).findall(p)
    for url in m:
        if 'openload' in url:
            c = c + 1
            c2 = addon.Lang(32055).encode('utf-8')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B] [B][COLOR green]%s[/COLOR][/B]%'
            %(name,c2,c),url,200,icon,addon.art,'')

def collection4(url):
    c = 0
    c2 = addon.Lang(32055).encode('utf-8')
    p = openn.Open_Url(url)
    m1 = re.compile('<meta property="og:image" content="(.+?)" />.+?<div class="contenidotv">.+?<h2>(.+?)</h2>',re.DOTALL).findall(p)
    for icon,name in m1:
        name = clean.Clean(name) 
        if '/ ' in name:
            name = name.split('/ ')[1] 
        m = re.compile('href="(.+?)"',re.DOTALL).findall(p)
    for url in m:
        if 'vidoza' in url:
            c = c + 1
            c2 = addon.Lang(32055).encode('utf-8')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B][B][COLOR green]%s[/COLOR][/B] [B][COLOR green]%s[/COLOR][/B]'
            %(name,c2,c),url,200,icon,addon.art,'')


def Search3():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = 'http://paidikestainies.online/?s=' + search
                katigoriaK(url)
        else: return  

def peirates(url):
        p = openn.Open_Url(url)
        m = re.compile('<div class="moviefilm">.+?<a href="(.+?)">.+?<img src="(.+?)" alt="(.+?)" height="125px" width="119px" title=".+?">',re.DOTALL).findall(p)
        for url,icon,name in m:
            name = name.split('&#038;')[0]
            name = name.split('&#8217;')[0]
            name = name.split('&#8211;')[0]
            icon = icon.replace('-119x125','')
            openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,8,icon,addon.art,'')
        try:
            m=re.compile('class="nextpostslink" rel="next" href="(.+?)">»</a>').findall(p)[0]
            openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,9,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
        except:pass
        setView.setView('movies', 'movie-view') 
 
def get_peirates(url):
        p = openn.Open_Url(url)
        m = re.compile('href="(.+?)"').findall(p)
        for url in m:
            if 'streamcloud'in url or'vidto'in url or'streamin'in url or'exashare.com'in url or'vidzi.tv'in url or'openload'in url or'hdvid'in url:
                name = url
                name = name.split('.')[0]
                name = name.replace('http://','').replace('https://','')
                openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,addon.icon,addon.art,'')


def yousmile():
    openn.addLink('[B][COLOR white]Yousmile[/COLOR][/B][B][COLOR green]Radio[/COLOR][/B]','http://eco.onestreaming.com:8352/;','','http://www.yousmile.gr/sites/all/themes/yousmile/images/radio_btn.png',addon.art,'')
    openn.addDir('[B][COLOR white]Εκπομπές[/COLOR][/B]','http://www.yousmile.gr/gallery?field_category_gallery_tid_i18n=1442',1001,'http://www.yousmile.gr/sites/default/files/logo_0.png',addon.art,'')
    openn.addDir('[B][COLOR white]Συνεντεύξεις[/COLOR][/B]','http://www.yousmile.gr/gallery?field_category_gallery_tid_i18n=1627',1001,'http://www.yousmile.gr/sites/default/files/logo_0.png',addon.art,'')
    openn.addDir('[B][COLOR white]Ρεπορτάζ[/COLOR][/B]','http://www.yousmile.gr/gallery?field_category_gallery_tid_i18n=1759',1001,'http://www.yousmile.gr/sites/default/files/logo_0.png',addon.art,'')
    openn.addDir('[B][COLOR white]Βίντεο[/COLOR][/B]','http://www.yousmile.gr/gallery?field_category_gallery_tid_i18n=1441',1001,'http://www.yousmile.gr/sites/default/files/logo_0.png',addon.art,'')

def yousmile1(url):
    p = openn.Open_Url(url)
    m = re.compile('<img typeof="foaf:Image" src="(.+?)" width="177" height="135" alt="" />.+?<span class="field-content"><a href="(.+?)">(.+?)</a></span>',re.DOTALL).findall(p)
    for icon,url,name in m:
        url = 'http://www.yousmile.gr' + url
        openn.addDir(name,url,1002,icon,addon.art,'')
    try:
        m=re.compile('<li class="pager-next last"><a href="(.+?)" title="Επόμενη σελίδα" class="active">επόμενη ›</a></li>').findall(p)[0]
        m = 'http://www.yousmile.gr' + m
        m = m.replace('amp;','')
        openn.addDir('[B][COLOR green]Next Page>>[/COLOR][/B]',m,1001,'http://i.imgur.com/rKSs0yq.png',addon.art,'[B][COLOR green]Επόμενη σελίδα[/COLOR][/B]')
    except:pass
    setView.setView('movies', 'movie-view') 

def yousmile2(name,url):
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser")
    for a in soup.findAll(class_="media-youtube-preview-wrapper"):
         url = a.embed['src']
         url = url.replace('v/','watch?v=')
         url = url.split('?version=3')[0]
         openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,'http://www.yousmile.gr/sites/default/files/logo_0.png',addon.art,'') 



    # p = openn.Open_Url(url)
    # m = re.compile('<param name="movie" value="(.+?)"></param>').findall(p)
    # for url in m:

    #     url = url.replace('v/','embed/')
    #     url = url.split('?version=3')[0]
    #     openn.addDir('[B][COLOR white]%s[/COLOR][/B]'%name,url,200,addon.icon,addon.art,'')


#<embed src="http://www.youtube.com/v/v5LXDZrTse8?version=3"
