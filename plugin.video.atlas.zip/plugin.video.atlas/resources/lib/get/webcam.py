# -*- coding: utf-8 -*-

import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time


from resources.lib.clean import addon

def cam():
    addLink('[B][COLOR white]Agios Dimitrios Viotias[/COLOR][/B]','http://livecameras.gr:8081/live/kopa1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Agios Nikolaos Halkidiki[/COLOR][/B]','http://livecameras.gr:8081/live/agnik1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Agios Nikolaos Sithonias[/COLOR][/B]','http://livecameras.gr:8081/live/agnik2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Agia Paraskeyi Kerasovo[/COLOR][/B]','http://livecameras.gr:8081/live/kera1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Akrata[/COLOR][/B]','http://livecameras.gr:8081/live/akra1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Ampelokipoi Thessalonikis[/COLOR][/B]','http://livecameras.gr:8081/live/thess1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Antikira Voiotias[/COLOR][/B]','http://livecameras.gr:8081/live/anti1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Antikira Voiotias 2[/COLOR][/B]','http://livecameras.gr:8081/live/anti2/chunks.m3u8',addon.icon)    
    addLink('[B][COLOR white]Arachova Voiotias[/COLOR][/B]','http://livecameras.gr:8081/live/arach1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Arachova Voiotias 2[/COLOR][/B]','http://livecameras.gr:8081/live/arach2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Aspovalta[/COLOR][/B]','http://livecameras.gr:8081/live/aspro1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Aspovalta 2[/COLOR][/B]','http://livecameras.gr:8081/live/aspro2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Avlonas Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/avlo1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Axarnes Parnitha[/COLOR][/B]','http://livecameras.gr:8081/live/parn1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Vouliagmeni Loutrakiou[/COLOR][/B]','http://livecameras.gr:8081/live/voulia1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Vrilissia Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/vrilis1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Vrilissia Attikis 2[/COLOR][/B]','http://livecameras.gr:8081/live/vrilis2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Vuronas[/COLOR][/B]','http://livecameras.gr:8081/live/vyro1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Vuronas 2[/COLOR][/B]','http://livecameras.gr:8081/live/vyro2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Gavalou Aitoloakarnanias[/COLOR][/B]','http://livecameras.gr:8081/live/gaval1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Galista Xalkidikis[/COLOR][/B]','http://livecameras.gr:8081/live/gaval1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Geraneia Ori[/COLOR][/B]','http://livecameras.gr:8081/live/gera1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Griva Paionias[/COLOR][/B]','http://livecameras.gr:8081/live/griv1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Dionusos Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/dion1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Drosia Patras[/COLOR][/B]','http://livecameras.gr:8081/live/patr1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Zeriki Voiotias[/COLOR][/B]','http://livecameras.gr:8081/live/zeri1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Zitsa Ioanninon[/COLOR][/B]','http://livecameras.gr:8081/live/zitsa1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Igoumenitsa[/COLOR][/B]','http://livecameras.gr:8081/live/igou1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Ithaki[/COLOR][/B]','http://livecameras.gr:8081/live/ithak1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Kaisari Korinthias[/COLOR][/B]','http://livecameras.gr:8081/live/kesa1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Kalamata[/COLOR][/B]','http://livecameras.gr:8081/live/kala1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Kalamata 2[/COLOR][/B]','http://livecameras.gr:8081/live/kala2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Kozani[/COLOR][/B]','http://livecameras.gr:8081/live/koza1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Komotini[/COLOR][/B]','http://livecameras.gr:8081/live/komo1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Konitsa Ioanninon[/COLOR][/B]','http://livecameras.gr:8081/live/koni1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Krestena Ileias[/COLOR][/B]','http://livecameras.gr:8081/live/kresten1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Krieza Evoias[/COLOR][/B]','http://livecameras.gr:8081/live/kriez1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Kuriaki Voiotias[/COLOR][/B]','http://livecameras.gr:8081/live/kyriak1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Laurio Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/lavr1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Levadia Voiotias[/COLOR][/B]','http://livecameras.gr:8081/live/leva1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Levadia Voiotias 2[/COLOR][/B]','http://livecameras.gr:8081/live/leva2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Levadia Voiotias 3[/COLOR][/B]','http://livecameras.gr:8081/live/leva3/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Levadia Kentro[/COLOR][/B]','http://livecameras.gr:8081/live/leva5/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Magouliana Arkadias[/COLOR][/B]','http://livecameras.gr:8081/live/magou1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Markopoulo Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/marko2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Mauroudi Igoumenitsas[/COLOR][/B]','http://livecameras.gr:8081/live/mavr1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Mesochoria Evoias[/COLOR][/B]','http://livecameras.gr:8081/live/meso1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Nea Selefkia Thesprotias[/COLOR][/B]','http://livecameras.gr:8081/live/nsel1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Neraida Kozanis[/COLOR][/B]','http://livecameras.gr:8081/live/nera1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Nymfaio Florinas[/COLOR][/B]','http://livecameras.gr:8081/live/nymf1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Oinofyta Voiotias[/COLOR][/B]','http://livecameras.gr:8081/live/oinof1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Parga[/COLOR][/B]','http://livecameras.gr:8081/live/parga2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Peiraias[/COLOR][/B]','http://livecameras.gr:8081/live/peir1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Pentalofo Kozanis[/COLOR][/B]','http://livecameras.gr:8081/live/penta1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Peraxora Loutrakiou[/COLOR][/B]','http://livecameras.gr:8081/live/pera1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Petroupoli Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/petr1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Pylos Messinias[/COLOR][/B]','http://livecameras.gr:8081/live/pylos1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Pylos Messinias 2[/COLOR][/B]','http://livecameras.gr:8081/live/pylos2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Pyrgos Hleias[/COLOR][/B]','http://livecameras.gr:8081/live/pirg1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Rea[/COLOR][/B]','http://livecameras.gr:8081/live/rea1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Romanos Patras[/COLOR][/B]','http://livecameras.gr:8081/live/roman1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Romanos Patras 2[/COLOR][/B]','http://livecameras.gr:8081/live/roman2/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Skopelos[/COLOR][/B]','http://livecameras.gr:8081/live/skop1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Stoxos Thessalonikis[/COLOR][/B]','http://livecameras.gr:8081/live/soho1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Steni Evoias[/COLOR][/B]','http://livecameras.gr:8081/live/steni1/chunks.m3u8',addon.icon)   
    addLink('[B][COLOR white]Tripoli Arkadias[/COLOR][/B]','http://livecameras.gr:8081/live/trip1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Ydra[/COLOR][/B]','http://livecameras.gr:8081/live/hydr1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Fyli Attikis[/COLOR][/B]','http://livecameras.gr:8081/live/fyli1/chunks.m3u8',addon.icon)
    addLink('[B][COLOR white]Xania Pilioy[/COLOR][/B]','http://livecameras.gr:8081/live/chan1/chunks.m3u8',addon.icon)
    #addLink('Xania Pilioy[/COLOR][/B]','',addon.icon)
    # addLink('Xania Pilioy[/COLOR][/B]','',addon.icon)

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok	